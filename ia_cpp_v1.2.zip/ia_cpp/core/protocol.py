"""Protocole d'echange de fichiers avec le modele.

Format canonique attendu :

    ===FILE: src/main.cpp ACTION: create===
    #include <iostream>
    ...
    ===END===

Le format balise est prefere au JSON : les petits modeles locaux cassent
frequemment un JSON strict (echappements, guillemets dans le code), alors
qu'ils respectent bien des balises de debut et de fin.

Trois passes de reconnaissance, de la plus stricte a la plus permissive :
  1. balises ===FILE: ... ACTION: ...===  (tolerantes aux decorations markdown)
  2. blocs de code annotes  ```cpp file="src/main.cpp"
  3. titre nommant un fichier suivi d'un bloc de code  ### src/main.cpp

La passe 3 rattrape le travers le plus frequent des modeles de petite taille :
livrer les fichiers sous forme de sections markdown malgre la consigne.
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field

ACTIONS = ("create", "replace", "delete")

# Jusqu'a 16 caracteres de decoration toleres avant la balise (**, ###, >, -)
_HEADER_RE = re.compile(
    r"^[^\n]{0,16}?={2,}[ \t]*FILE[ \t]*:[ \t]*(?P<path>[^=\n]+?)"
    r"(?:[ \t]+ACTION[ \t]*:[ \t]*(?P<action>[A-Za-z]+))?[ \t]*={2,}[^\n]{0,8}$",
    re.IGNORECASE | re.MULTILINE,
)
_END_RE = re.compile(r"^[^\n]{0,16}?={2,}[ \t]*END[ \t]*={2,}[^\n]{0,8}$",
                     re.IGNORECASE | re.MULTILINE)

_FENCE_RE = re.compile(
    r"^[ \t]*```[A-Za-z0-9+#.]*[ \t]+(?:file|path)[ \t]*=[ \t]*[\"']?(?P<path>[^\"'\n`]+?)[\"']?"
    r"(?:[ \t]+action[ \t]*=[ \t]*[\"']?(?P<action>[A-Za-z]+)[\"']?)?[ \t]*$",
    re.IGNORECASE | re.MULTILINE,
)
_FENCE_END_RE = re.compile(r"^[ \t]*```[ \t]*$", re.MULTILINE)

# Passe 3 : un titre markdown (ou une ligne en gras) qui nomme un fichier,
# suivi, dans les lignes qui suivent, d'un bloc de code.
_SOURCE_SUFFIXES = (
    "cpp", "cc", "cxx", "c", "h", "hpp", "hxx", "hh", "ipp", "inl",
    "cmake", "md", "json", "yml", "yaml", "txt", "bat", "sh", "in",
)
_FILENAME_HEADING_RE = re.compile(
    r"^[ \t]*(?:#{1,6}[ \t]*|[*_]{1,2}|[-*][ \t]+)?"
    r"[`\"']?(?P<path>(?:[\w.\-]+/)*(?:CMakeLists\.txt|Makefile|[\w.\-]+\.(?:"
    + "|".join(_SOURCE_SUFFIXES) + r")))[`\"']?"
    r"[ \t]*[:\-]?[ \t]*[*_]{0,2}[ \t]*$",
    re.IGNORECASE | re.MULTILINE,
)
_OPEN_FENCE_RE = re.compile(r"^[ \t]*```[A-Za-z0-9+#.]*[ \t]*$", re.MULTILINE)

_WRAPPED_FENCE_RE = re.compile(
    r"\A[ \t]*```[A-Za-z0-9+#.]*[ \t]*\n(?P<body>.*?)\n[ \t]*```[ \t]*\Z",
    re.DOTALL,
)


@dataclass
class FileOp:
    path: str
    action: str
    content: str
    source: str = "tag"
    warnings: list[str] = field(default_factory=list)

    @property
    def is_delete(self) -> bool:
        return self.action == "delete"


def _normalise_action(raw: str | None) -> str:
    if not raw:
        return "replace"
    aliases = {
        "create": "create", "new": "create", "add": "create", "nouveau": "create",
        "replace": "replace", "update": "replace", "modify": "replace",
        "patch": "replace", "edit": "replace", "overwrite": "replace",
        "rewrite": "replace", "write": "replace", "modifier": "replace",
        "delete": "delete", "remove": "delete", "supprimer": "delete",
    }
    return aliases.get(raw.strip().lower(), "replace")


def _clean_content(text: str) -> str:
    text = text.strip("\n")
    wrapped = _WRAPPED_FENCE_RE.match(text)
    if wrapped:
        text = wrapped.group("body")
    if text and not text.endswith("\n"):
        text += "\n"
    return text


def _normalise_path(raw: str) -> str:
    path = raw.strip().strip("\"'`* ")
    path = path.replace("\\", "/")
    while path.startswith("./"):
        path = path[2:]
    return path.strip("/")


def _flag_suspicious(op: FileOp) -> None:
    """Signale les chemins qui seront de toute facon refuses a l'ecriture."""
    path = op.path
    if not path:
        op.warnings.append("chemin vide")
        return
    if path.startswith("/") or re.match(r"^[A-Za-z]:", path):
        op.warnings.append("chemin absolu : sera refuse a l'ecriture")
    if ".." in path.split("/"):
        op.warnings.append("remontee '..' : sera refusee a l'ecriture")


def _scan_tagged(text: str) -> list[tuple[int, int, FileOp]]:
    spans: list[tuple[int, int, FileOp]] = []
    for match in _HEADER_RE.finditer(text):
        body_start = match.end()
        end_match = _END_RE.search(text, body_start)
        next_header = _HEADER_RE.search(text, body_start)
        if end_match and (not next_header or end_match.start() <= next_header.start()):
            body = text[body_start:end_match.start()]
            block_end = end_match.end()
            warnings: list[str] = []
        else:
            stop = next_header.start() if next_header else len(text)
            body = text[body_start:stop]
            block_end = stop
            warnings = ["bloc non termine par ===END=== (contenu pris jusqu'au bloc suivant)"]
        op = FileOp(
            path=_normalise_path(match.group("path")),
            action=_normalise_action(match.group("action")),
            content=_clean_content(body),
            source="tag",
            warnings=warnings,
        )
        _flag_suspicious(op)
        spans.append((match.start(), block_end, op))
    return spans


def _scan_annotated_fences(text: str) -> list[tuple[int, int, FileOp]]:
    spans: list[tuple[int, int, FileOp]] = []
    for match in _FENCE_RE.finditer(text):
        body_start = match.end()
        end_match = _FENCE_END_RE.search(text, body_start)
        stop = end_match.start() if end_match else len(text)
        block_end = end_match.end() if end_match else len(text)
        op = FileOp(
            path=_normalise_path(match.group("path")),
            action=_normalise_action(match.group("action")),
            content=_clean_content(text[body_start:stop]),
            source="fence",
        )
        _flag_suspicious(op)
        spans.append((match.start(), block_end, op))
    return spans


def _scan_heading_fences(text: str) -> list[tuple[int, int, FileOp]]:
    """Titre nommant un fichier, puis bloc de code dans les lignes suivantes."""
    spans: list[tuple[int, int, FileOp]] = []
    for match in _FILENAME_HEADING_RE.finditer(text):
        after = text[match.end():]
        fence = _OPEN_FENCE_RE.search(after)
        if not fence:
            continue
        # le bloc doit suivre de pres le titre (au plus 3 lignes de prose)
        between = after[:fence.start()]
        if between.count("\n") > 4:
            continue
        body_start = match.end() + fence.end()
        end_match = _FENCE_END_RE.search(text, body_start)
        if not end_match:
            continue
        op = FileOp(
            path=_normalise_path(match.group("path")),
            action="replace",
            content=_clean_content(text[body_start:end_match.start()]),
            source="heading",
            warnings=["bloc reconstruit depuis un titre markdown : "
                      "verifie que le contenu est bien le fichier complet"],
        )
        _flag_suspicious(op)
        if op.content.strip():
            spans.append((match.start(), end_match.end(), op))
    return spans


def parse_response(text: str) -> tuple[list[FileOp], str]:
    """Extrait les operations fichier et retourne le texte nettoye pour affichage."""
    spans = _scan_tagged(text)
    if not spans:
        spans = _scan_annotated_fences(text)

    # La passe 3 vient toujours en complement : un modele livre souvent la
    # plupart des fichiers correctement puis decroche sur le dernier
    # (typiquement le CMakeLists.txt, presente comme une section markdown).
    # On ne retient que les blocs qui ne chevauchent rien de deja reconnu.
    covered = [(start, end) for start, end, _ in spans]
    known = {op.path for _, _, op in spans}
    for start, end, op in _scan_heading_fences(text):
        if op.path in known:
            continue
        if any(start < c_end and end > c_start for c_start, c_end in covered):
            continue
        spans.append((start, end, op))
        covered.append((start, end))
        known.add(op.path)

    if not spans:
        return [], text

    spans.sort(key=lambda item: item[0])
    ops: list[FileOp] = []
    pieces: list[str] = []
    cursor = 0
    for start, end, op in spans:
        if start < cursor:   # chevauchement : on ignore le bloc redondant
            continue
        pieces.append(text[cursor:start])
        label = {"create": "creation", "replace": "remplacement",
                 "delete": "suppression"}[op.action]
        if op.action == "delete":
            pieces.append(f"\n[-- {label} : {op.path} --]\n")
        else:
            pieces.append(f"\n[-- {label} : {op.path} ({op.content.count(chr(10))} lignes) --]\n")
        cursor = end
        ops.append(op)
    pieces.append(text[cursor:])

    # deduplication : la derniere version d'un meme chemin gagne
    unique: dict[str, FileOp] = {}
    for op in ops:
        unique[op.path] = op
    deduped = [op for op in ops if unique[op.path] is op]
    return deduped, "".join(pieces).strip()


def looks_like_code_answer(text: str) -> bool:
    """Vrai si la reponse contient manifestement du code non livre en blocs."""
    if "```" in text:
        return True
    markers = ("===END", "===FILE", "#include", "int main(", "cmake_minimum_required")
    return any(marker in text for marker in markers)


def strip_think_blocks(text: str) -> str:
    """Retire les blocs de raisonnement <think>...</think> de certains modeles."""
    return re.sub(r"<think>.*?</think>", "", text, flags=re.DOTALL | re.IGNORECASE).strip()
