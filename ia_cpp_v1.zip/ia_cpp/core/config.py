"""Configuration portable de l'application.

La configuration et la base de donnees vivent par defaut dans <dossier app>/data,
ce qui rend l'installation portable (clef USB, D:\\Dev\\..., etc.).
La variable d'environnement IA_CPP_HOME permet de deplacer ce dossier.
"""
from __future__ import annotations

import json
import os
from pathlib import Path

APP_DIR = Path(__file__).resolve().parent.parent

DEFAULTS: dict = {
    # --- Ollama ---
    "ollama_url": "http://localhost:11434",
    "model_code": "qwen2.5-coder:7b",     # modele principal pour generer du C++
    "model_light": "gemma4:e2b",          # resumes, titres, taches rapides
    "model_embed": "nomic-embed-text",    # embeddings pour la base de savoirs
    "temperature_code": 0.15,
    "temperature_light": 0.30,
    "num_ctx": 8192,
    "request_timeout": 900,

    # --- Budget de contexte ---
    "context_budget_tokens": 6000,
    "keep_last_messages": 8,
    "summarize_after_messages": 14,
    "rag_top_k": 5,

    # --- Securite / fichiers ---
    "require_diff_approval": True,
    "backup_before_write": True,
    "allowed_extensions": [
        ".cpp", ".cc", ".cxx", ".c", ".h", ".hpp", ".hxx", ".hh", ".ipp", ".inl",
        ".cmake", ".txt", ".md", ".json", ".yml", ".yaml", ".in", ".bat", ".sh",
        ".ui", ".qrc", ".rc",
    ],
    "allowed_filenames": [
        "CMakeLists.txt", "Makefile", "makefile", ".clang-format", ".clang-tidy",
        ".gitignore", "conanfile.txt", "vcpkg.json",
    ],
    "max_manifest_files": 150,
    "max_file_bytes": 400_000,

    # --- Git ---
    "git_enabled": True,
    "git_auto_commit": True,

    # --- Divers ---
    "theme": "clam",
    "font_mono": "Consolas" if os.name == "nt" else "DejaVu Sans Mono",
    "font_size": 10,
}


def data_dir() -> Path:
    env = os.environ.get("IA_CPP_HOME")
    path = Path(env).expanduser() if env else APP_DIR / "data"
    path.mkdir(parents=True, exist_ok=True)
    return path


def db_path() -> Path:
    return data_dir() / "ia_cpp.db"


def log_dir() -> Path:
    path = data_dir() / "logs"
    path.mkdir(parents=True, exist_ok=True)
    return path


def knowledge_dir() -> Path:
    path = APP_DIR / "knowledge"
    path.mkdir(parents=True, exist_ok=True)
    return path


def prompts_dir() -> Path:
    path = APP_DIR / "prompts"
    path.mkdir(parents=True, exist_ok=True)
    return path


class Config:
    """Acces typo-tolerant a la configuration, persistee en JSON."""

    def __init__(self, path: Path | None = None) -> None:
        self.path = path or (data_dir() / "config.json")
        self._data: dict = dict(DEFAULTS)
        self.load()

    # ------------------------------------------------------------------ IO
    def load(self) -> None:
        if self.path.exists():
            try:
                raw = json.loads(self.path.read_text(encoding="utf-8"))
                if isinstance(raw, dict):
                    # on fusionne pour recuperer les nouvelles clefs des mises a jour
                    self._data.update({k: v for k, v in raw.items() if k in DEFAULTS or True})
            except (json.JSONDecodeError, OSError):
                pass
        # garantit la presence de toutes les clefs par defaut
        for key, value in DEFAULTS.items():
            self._data.setdefault(key, value)

    def save(self) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        tmp = self.path.with_suffix(".tmp")
        tmp.write_text(json.dumps(self._data, indent=2, ensure_ascii=False), encoding="utf-8")
        tmp.replace(self.path)

    # --------------------------------------------------------------- acces
    def __getitem__(self, key: str):
        return self._data[key]

    def __setitem__(self, key: str, value) -> None:
        self._data[key] = value

    def get(self, key: str, default=None):
        return self._data.get(key, default)

    def set(self, key: str, value) -> None:
        self._data[key] = value

    def update(self, values: dict) -> None:
        self._data.update(values)

    def as_dict(self) -> dict:
        return dict(self._data)

    def reset(self) -> None:
        self._data = dict(DEFAULTS)
