"""Orchestration : relie configuration, base, Ollama, savoirs et fichiers.

L'interface graphique ne parle qu'a cette classe. Toute la logique metier
(construction du contexte, streaming, parsing, ecriture, commit, resume)
est ici, ce qui la rend testable sans Tkinter.
"""
from __future__ import annotations

import json
import threading
import time
from dataclasses import dataclass, field
from pathlib import Path

from . import context as ctx
from . import errors as err
from . import files as fs
from . import gitrepo
from .config import Config, log_dir, prompts_dir
from .db import Database
from .ollama_client import OllamaClient, OllamaError
from .protocol import FileOp, parse_response, strip_think_blocks
from .rag import KnowledgeBase, estimate_tokens

DEFAULT_SYSTEM_PROMPT = """\
Tu es un ingenieur C++ senior qui travaille en binome avec un developpeur sur
une machine locale. Tu produis du code C++ moderne, complet et compilable.

Methode de travail :
- Avant d'ecrire, enonce en 2 a 5 lignes ce que tu vas faire et quels fichiers
  tu vas toucher.
- Un fichier par responsabilite : en-tete (.h/.hpp) pour les declarations,
  source (.cpp) pour les definitions.
- Pas de dependance externe sans l'avoir annoncee et justifiee.
- Prefere la bibliotheque standard. Pas de new/delete nus : conteneurs
  standard, std::unique_ptr, std::shared_ptr.
- Gere les erreurs explicitement, documente les invariants non evidents.
- Si la demande est ambigue, pose une question courte AVANT de coder plutot
  que d'inventer des hypotheses silencieuses.
- Reponds en francais ; le code, les identifiants et les commentaires de code
  restent en anglais sauf consigne contraire du projet.
"""


@dataclass
class GenerationResult:
    raw_text: str = ""
    display_text: str = ""
    ops: list[FileOp] = field(default_factory=list)
    stats: ctx.ContextStats | None = None
    model: str = ""
    duration: float = 0.0
    stopped: bool = False
    error: str = ""


class Engine:
    def __init__(self, config: Config, db: Database) -> None:
        self.config = config
        self.db = db
        self.client = OllamaClient(config["ollama_url"], int(config["request_timeout"]))
        self.knowledge = KnowledgeBase(self.db, self.client, config["model_embed"])
        self.stop_event = threading.Event()

    # ------------------------------------------------------------- reglages
    def refresh_clients(self) -> None:
        self.client.base_url = str(self.config["ollama_url"]).rstrip("/")
        self.client.timeout = int(self.config["request_timeout"])
        self.knowledge.embed_model = self.config["model_embed"]

    def base_system_prompt(self) -> str:
        path = prompts_dir() / "system_code.md"
        if path.exists():
            text = path.read_text(encoding="utf-8").strip()
            if text:
                return text
        return DEFAULT_SYSTEM_PROMPT

    def code_options(self) -> dict:
        return {
            "temperature": float(self.config["temperature_code"]),
            "num_ctx": int(self.config["num_ctx"]),
        }

    def light_options(self) -> dict:
        return {
            "temperature": float(self.config["temperature_light"]),
            "num_ctx": min(int(self.config["num_ctx"]), 8192),
        }

    # ------------------------------------------------------------ contexte
    def pending_error_block(self, project) -> str:
        rows = self.db.open_errors(int(project["id"]))
        if not rows:
            return ""
        raw = rows[0]["raw_text"]
        issues = [
            err.BuildIssue(file=r["file"], line=int(r["line"]), col=int(r["col"]),
                           kind=r["kind"], code=r["code"], text=r["text"], raw=r["raw_text"])
            for r in rows
        ]
        return err.build_error_context(raw, issues, Path(project["path"]), fs.excerpt_around)

    def build_context(self, project, conversation_id: int, user_prompt: str,
                      use_rag: bool = True, use_manifest: bool = True,
                      extra_system: str = "") -> ctx.BuiltContext:
        system_prompt = ctx.build_system_prompt(self.base_system_prompt(), project, extra_system)

        knowledge_block = ""
        if use_rag:
            pack_ids = self.db.enabled_pack_ids(int(project["id"]))
            if pack_ids:
                hits = self.knowledge.search(user_prompt, pack_ids, int(self.config["rag_top_k"]))
                knowledge_block = self.knowledge.format_hits(hits)

        manifest_block = ""
        if use_manifest:
            manifest_block = fs.build_manifest(
                project["path"],
                list(self.config["allowed_extensions"]),
                list(self.config["allowed_filenames"]),
                int(self.config["max_manifest_files"]),
            )
            head = gitrepo.head_short(project["path"])
            if head:
                manifest_block += f"\n\nDernier commit git : {head}"

        summary_row = self.db.latest_summary(conversation_id)
        summary_text = summary_row["content"] if summary_row else ""
        after_id = int(summary_row["up_to_message_id"]) if summary_row else 0

        history = [
            {"role": row["role"], "content": row["content"]}
            for row in self.db.list_messages(conversation_id, after_id=after_id)
        ]

        return ctx.build_messages(
            system_prompt=system_prompt,
            knowledge_block=knowledge_block,
            manifest_block=manifest_block,
            summary_text=summary_text,
            history=history,
            error_block=self.pending_error_block(project),
            user_prompt=user_prompt,
            budget_tokens=int(self.config["context_budget_tokens"]),
            keep_last=int(self.config["keep_last_messages"]),
        )

    # ----------------------------------------------------------- generation
    def generate(self, project, conversation_id: int, user_prompt: str,
                 on_chunk=None, use_rag: bool = True, use_manifest: bool = True,
                 extra_system: str = "") -> GenerationResult:
        self.stop_event.clear()
        self.refresh_clients()
        built = self.build_context(project, conversation_id, user_prompt,
                                   use_rag, use_manifest, extra_system)
        model = str(self.config["model_code"])
        started = time.time()
        pieces: list[str] = []
        error_message = ""
        try:
            for piece in self.client.chat_stream(model, built.messages,
                                                 self.code_options(), self.stop_event):
                pieces.append(piece)
                if on_chunk:
                    on_chunk(piece)
        except OllamaError as exc:
            error_message = str(exc)

        raw = "".join(pieces)
        cleaned = strip_think_blocks(raw)
        ops, display = parse_response(cleaned)
        result = GenerationResult(
            raw_text=raw,
            display_text=display or cleaned,
            ops=ops,
            stats=built.stats,
            model=model,
            duration=time.time() - started,
            stopped=self.stop_event.is_set(),
            error=error_message,
        )
        self._log_exchange(project, conversation_id, built, result)
        return result

    def stop(self) -> None:
        self.stop_event.set()

    def _log_exchange(self, project, conversation_id: int,
                      built: ctx.BuiltContext, result: GenerationResult) -> None:
        try:
            path = log_dir() / f"{time.strftime('%Y-%m-%d')}.jsonl"
            record = {
                "ts": time.time(),
                "project": project["name"],
                "conversation_id": conversation_id,
                "model": result.model,
                "duration_s": round(result.duration, 2),
                "context": built.stats.describe(),
                "messages": built.messages,
                "response": result.raw_text,
                "files": [{"path": op.path, "action": op.action} for op in result.ops],
                "error": result.error,
            }
            with open(path, "a", encoding="utf-8") as handle:
                handle.write(json.dumps(record, ensure_ascii=False) + "\n")
        except OSError:
            pass

    # ------------------------------------------------------- application
    def apply_ops(self, project, ops: list[FileOp], message_id: int = 0,
                  commit_message: str = "") -> tuple[list[fs.ApplyResult], str]:
        root = Path(project["path"])
        results: list[fs.ApplyResult] = []
        for op in ops:
            result = fs.apply_op(
                root, op.path, op.action, op.content,
                list(self.config["allowed_extensions"]),
                list(self.config["allowed_filenames"]),
                bool(self.config["backup_before_write"]),
                int(self.config["max_file_bytes"]),
            )
            results.append(result)
            if result.ok:
                self.db.record_file(int(project["id"]), op.path, op.action,
                                    result.sha256, message_id, result.backup, result.size)

        git_message = ""
        written = [r.path for r in results if r.ok]
        if written and self.config["git_enabled"] and self.config["git_auto_commit"]:
            ok, info = gitrepo.ensure_repo(root)
            if ok:
                label = commit_message or f"IA C++ : {len(written)} fichier(s)"
                done, detail = gitrepo.commit(root, label[:200], written)
                git_message = f"git : {detail}" if done else f"git (echec) : {detail}"
            else:
                git_message = f"git indisponible : {info}"
        return results, git_message

    # ------------------------------------------------- erreurs de compilation
    def register_build_output(self, project, raw_text: str) -> list[err.BuildIssue]:
        issues = err.parse_build_output(raw_text, Path(project["path"]))
        self.db.add_build_errors(
            int(project["id"]), raw_text,
            [{"file": i.file, "line": i.line, "col": i.col, "kind": i.kind,
              "code": i.code, "text": i.text} for i in issues],
        )
        return issues

    def clear_build_errors(self, project) -> None:
        self.db.resolve_errors(int(project["id"]))

    # ------------------------------------------------- resume / titre
    def maybe_summarise(self, conversation_id: int, force: bool = False) -> str:
        threshold = int(self.config["summarize_after_messages"])
        summary_row = self.db.latest_summary(conversation_id)
        after_id = int(summary_row["up_to_message_id"]) if summary_row else 0
        rows = self.db.list_messages(conversation_id, after_id=after_id)
        if not force and len(rows) < threshold:
            return ""
        if len(rows) < 4:
            return ""
        keep = int(self.config["keep_last_messages"])
        to_summarise = rows[:-keep] if len(rows) > keep else rows
        if len(to_summarise) < 2:
            return ""
        history = [{"role": r["role"], "content": r["content"]} for r in to_summarise]
        previous = summary_row["content"] if summary_row else ""
        try:
            text = self.client.chat(
                str(self.config["model_light"]),
                ctx.summary_messages(previous, history),
                self.light_options(),
            )
        except OllamaError as exc:
            return f"(resume impossible : {exc})"
        text = strip_think_blocks(text).strip()
        if text:
            self.db.add_summary(conversation_id, text, int(to_summarise[-1]["id"]))
        return text

    def suggest_title(self, prompt: str) -> str:
        try:
            text = self.client.chat(
                str(self.config["model_light"]),
                ctx.title_messages(prompt),
                self.light_options(),
            )
        except OllamaError:
            return ""
        title = strip_think_blocks(text).strip().strip('"\'').splitlines()[0] if text.strip() else ""
        return title[:80]

    # ---------------------------------------------------------------- divers
    def estimate(self, text: str) -> int:
        return estimate_tokens(text)
