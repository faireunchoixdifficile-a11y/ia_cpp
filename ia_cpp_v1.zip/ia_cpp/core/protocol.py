"""Protocole d'echange de fichiers avec le modele.

Le modele doit encadrer chaque fichier par des balises explicites :

    ===FILE: src/main.cpp ACTION: create===
    #include <iostream>
    ...
    ===END===

Le format balise est volontairement prefere au JSON : les petits modeles
locaux cassent frequemment un JSON strict (echappements, guillemets dans le
code), alors qu'ils respectent bien des balises de debut et de fin.

Plusieurs variantes tolerees :
  ===FILE: path ACTION: replace===      (forme canonique)
  ===FILE: path===                      (action deduite : replace)
  ```cpp file="src/main.cpp"            (bloc de code annote)
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field

ACTIONS = ("create", "replace", "delete")

_HEADER_RE = re.compile(
    r"^[ \t]*={2,}\s*FILE\s*:\s*(?P<path>[^=\n]+?)"
    r"(?:\s+ACTION\s*:\s*(?P<action>[A-Za-z]+))?\s*={2,}[ \t]*$",
    re.IGNORECASE | re.MULTILINE,
)
_END_RE = re.compile(r"^[ \t]*={2,}\s*END\s*={2,}[ \t]*$", re.IGNORECASE | re.MULTILINE)

_FENCE_RE = re.compile(
    r"^[ \t]*```[A-Za-z0-9+#.]*\s+(?:file|path)\s*=\s*[\"']?(?P<path>[^\"'\n`]+?)[\"']?"
    r"(?:\s+action\s*=\s*[\"']?(?P<action>[A-Za-z]+)[\"']?)?[ \t]*$",
    re.IGNORECASE | re.MULTILINE,
)
_FENCE_END_RE = re.compile(r"^[ \t]*```[ \t]*$", re.MULTILINE)

# un bloc de code interne eventuellement produit par le modele autour du contenu
_WRAPPED_FENCE_RE = re.compile(
    r"\A[ \t]*```[A-Za-z0-9+#.]*[ \t]*\n(?P<body>.*?)\n[ \t]*```[ \t]*\Z",
    re.DOTALL,
)


@dataclass
class FileOp:
    path: str
    action: str
    content: str
    source: str = "tag"
    warnings: list[str] = field(default_factory=list)

    @property
    def is_delete(self) -> bool:
        return self.action == "delete"


def _normalise_action(raw: str | None) -> str:
    if not raw:
        return "replace"
    value = raw.strip().lower()
    aliases = {
        "create": "create", "new": "create", "add": "create",
        "replace": "replace", "update": "replace", "modify": "replace",
        "patch": "replace", "edit": "replace", "overwrite": "replace",
        "rewrite": "replace", "write": "replace",
        "delete": "delete", "remove": "delete",
    }
    return aliases.get(value, "replace")


def _clean_content(text: str) -> str:
    text = text.strip("\n")
    wrapped = _WRAPPED_FENCE_RE.match(text)
    if wrapped:
        text = wrapped.group("body")
    if text and not text.endswith("\n"):
        text += "\n"
    return text


def _normalise_path(raw: str) -> str:
    path = raw.strip().strip("\"'` ")
    path = path.replace("\\", "/")
    while path.startswith("./"):
        path = path[2:]
    return path.strip("/")


def _flag_suspicious(op: "FileOp") -> None:
    """Signale les chemins qui seront de toute facon refuses a l'ecriture."""
    path = op.path
    if path.startswith("/") or re.match(r"^[A-Za-z]:", path):
        op.warnings.append("chemin absolu : sera refuse a l'ecriture")
    if ".." in path.split("/"):
        op.warnings.append("remontee '..' : sera refusee a l'ecriture")
    if not path:
        op.warnings.append("chemin vide")


def parse_response(text: str) -> tuple[list[FileOp], str]:
    """Extrait les operations fichier et retourne le texte nettoye pour affichage."""
    ops: list[FileOp] = []
    spans: list[tuple[int, int, FileOp]] = []

    for match in _HEADER_RE.finditer(text):
        body_start = match.end()
        end_match = _END_RE.search(text, body_start)
        next_header = _HEADER_RE.search(text, body_start)
        if end_match and (not next_header or end_match.start() <= next_header.start()):
            body = text[body_start:end_match.start()]
            block_end = end_match.end()
            warnings: list[str] = []
        else:
            # bloc non termine : on prend jusqu'au prochain entete ou la fin
            stop = next_header.start() if next_header else len(text)
            body = text[body_start:stop]
            block_end = stop
            warnings = ["bloc non termine par ===END=== (contenu pris jusqu'au bloc suivant)"]
        op = FileOp(
            path=_normalise_path(match.group("path")),
            action=_normalise_action(match.group("action")),
            content=_clean_content(body),
            source="tag",
            warnings=warnings,
        )
        _flag_suspicious(op)
        spans.append((match.start(), block_end, op))

    if not spans:
        for match in _FENCE_RE.finditer(text):
            body_start = match.end()
            end_match = _FENCE_END_RE.search(text, body_start)
            stop = end_match.start() if end_match else len(text)
            block_end = end_match.end() if end_match else len(text)
            op = FileOp(
                path=_normalise_path(match.group("path")),
                action=_normalise_action(match.group("action")),
                content=_clean_content(text[body_start:stop]),
                source="fence",
            )
            _flag_suspicious(op)
            spans.append((match.start(), block_end, op))

    if not spans:
        return [], text

    spans.sort(key=lambda item: item[0])
    pieces: list[str] = []
    cursor = 0
    for start, end, op in spans:
        pieces.append(text[cursor:start])
        label = {"create": "creation", "replace": "remplacement", "delete": "suppression"}[op.action]
        lines = op.content.count("\n")
        if op.action == "delete":
            pieces.append(f"\n[-- {label} : {op.path} --]\n")
        else:
            pieces.append(f"\n[-- {label} : {op.path} ({lines} lignes) --]\n")
        cursor = end
        ops.append(op)
    pieces.append(text[cursor:])

    # deduplication : la derniere version d'un meme chemin gagne
    unique: dict[str, FileOp] = {}
    for op in ops:
        unique[op.path] = op
    deduped = [op for op in ops if unique[op.path] is op]
    return deduped, "".join(pieces).strip()


def strip_think_blocks(text: str) -> str:
    """Retire les blocs de raisonnement <think>...</think> de certains modeles."""
    return re.sub(r"<think>.*?</think>", "", text, flags=re.DOTALL | re.IGNORECASE).strip()
