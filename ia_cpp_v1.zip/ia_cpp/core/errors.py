"""Parsing des sorties de compilateur (MSVC, GCC/Clang, CMake, linker).

Objectif : transformer un copier-coller brut en liste structuree, puis
fabriquer un contexte compact (erreur + extrait de source autour de la ligne)
a reinjecter dans le prompt.
"""
from __future__ import annotations

import re
from dataclasses import dataclass
from pathlib import Path

# gcc / clang :  src/main.cpp:12:5: error: 'foo' was not declared
GCC_RE = re.compile(
    r"^\s*(?P<file>[^:\n]+?):(?P<line>\d+):(?:(?P<col>\d+):)?\s*"
    r"(?P<kind>error|warning|note|fatal error)\s*:\s*(?P<text>.+)$",
    re.IGNORECASE,
)
# msvc :  C:\dev\main.cpp(12,5): error C2065: 'foo': identificateur non declare
MSVC_RE = re.compile(
    r"^\s*(?P<file>(?:[A-Za-z]:)?[^(\n]+?)\((?P<line>\d+)(?:,(?P<col>\d+))?\)\s*:\s*"
    r"(?P<kind>error|warning|fatal error)\s+(?P<code>[A-Z]+\d+)\s*:\s*(?P<text>.+)$",
    re.IGNORECASE,
)
# linker msvc : main.obj : error LNK2019: symbole externe non resolu ...
LINK_RE = re.compile(
    r"^\s*(?P<file>[^:\n]+?)\s*:\s*(?P<kind>error|warning)\s+(?P<code>LNK\d+)\s*:\s*(?P<text>.+)$",
    re.IGNORECASE,
)
# ld : undefined reference to `foo()'
LD_RE = re.compile(r"undefined reference to [`'\"](?P<symbol>[^`'\"]+)", re.IGNORECASE)
CMAKE_RE = re.compile(
    r"^\s*CMake (?P<kind>Error|Warning)(?: at (?P<file>[^:\n]+):(?P<line>\d+))?",
    re.IGNORECASE,
)


@dataclass
class BuildIssue:
    file: str = ""
    line: int = 0
    col: int = 0
    kind: str = "error"
    code: str = ""
    text: str = ""
    raw: str = ""

    def label(self) -> str:
        where = self.file or "(global)"
        if self.line:
            where += f":{self.line}"
            if self.col:
                where += f":{self.col}"
        code = f" {self.code}" if self.code else ""
        return f"[{self.kind}{code}] {where} - {self.text}"


def _relative(file: str, root: Path | None) -> str:
    cleaned = file.strip().strip('"')
    if not cleaned:
        return ""
    if root is None:
        return cleaned.replace("\\", "/")
    try:
        candidate = Path(cleaned)
        if candidate.is_absolute():
            return str(candidate.resolve().relative_to(Path(root).resolve())).replace("\\", "/")
    except (ValueError, OSError):
        pass
    return cleaned.replace("\\", "/")


def parse_build_output(text: str, root: Path | str | None = None) -> list[BuildIssue]:
    root_path = Path(root) if root else None
    issues: list[BuildIssue] = []
    seen: set[tuple] = set()

    for raw_line in text.splitlines():
        line = raw_line.rstrip()
        if not line.strip():
            continue
        issue: BuildIssue | None = None

        match = MSVC_RE.match(line)
        if match:
            issue = BuildIssue(
                file=_relative(match.group("file"), root_path),
                line=int(match.group("line") or 0),
                col=int(match.group("col") or 0),
                kind=match.group("kind").lower().replace("fatal error", "error"),
                code=match.group("code") or "",
                text=match.group("text").strip(),
                raw=line,
            )
        if issue is None:
            match = GCC_RE.match(line)
            if match:
                issue = BuildIssue(
                    file=_relative(match.group("file"), root_path),
                    line=int(match.group("line") or 0),
                    col=int(match.group("col") or 0),
                    kind=match.group("kind").lower().replace("fatal error", "error"),
                    text=match.group("text").strip(),
                    raw=line,
                )
        if issue is None:
            match = LINK_RE.match(line)
            if match:
                issue = BuildIssue(
                    file=_relative(match.group("file"), root_path),
                    kind=match.group("kind").lower(),
                    code=match.group("code"),
                    text=match.group("text").strip(),
                    raw=line,
                )
        if issue is None:
            match = CMAKE_RE.match(line)
            if match:
                issue = BuildIssue(
                    file=_relative(match.group("file") or "", root_path),
                    line=int(match.group("line") or 0),
                    kind=match.group("kind").lower(),
                    code="CMake",
                    text=line.strip(),
                    raw=line,
                )
        if issue is None:
            match = LD_RE.search(line)
            if match:
                issue = BuildIssue(
                    kind="error",
                    code="LD",
                    text=f"reference non resolue : {match.group('symbol')}",
                    raw=line,
                )

        if issue is None:
            continue
        key = (issue.file, issue.line, issue.col, issue.code, issue.text[:80])
        if key in seen:
            continue
        seen.add(key)
        issues.append(issue)

    return issues


def summarise(issues: list[BuildIssue]) -> str:
    errors = sum(1 for i in issues if i.kind == "error")
    warnings = sum(1 for i in issues if i.kind == "warning")
    parts = []
    if errors:
        parts.append(f"{errors} erreur(s)")
    if warnings:
        parts.append(f"{warnings} avertissement(s)")
    others = len(issues) - errors - warnings
    if others:
        parts.append(f"{others} autre(s)")
    return ", ".join(parts) if parts else "aucun probleme reconnu"


def build_error_context(raw_text: str, issues: list[BuildIssue], root: Path | str,
                        excerpt_fn, max_files: int = 4, max_chars: int = 7000) -> str:
    """Compose le bloc a reinjecter : erreurs + extraits de code concernes."""
    lines: list[str] = ["## Sortie de compilation (brute, tronquee)"]
    trimmed = raw_text.strip()
    if len(trimmed) > 2500:
        trimmed = trimmed[:2500] + "\n... (tronque)"
    lines.append("```")
    lines.append(trimmed)
    lines.append("```")

    errors = [i for i in issues if i.kind == "error"] or issues
    if errors:
        lines.append("")
        lines.append("## Problemes identifies")
        for issue in errors[:25]:
            lines.append(f"- {issue.label()}")

    done: set[str] = set()
    for issue in errors:
        if len(done) >= max_files:
            break
        if not issue.file or issue.file in done:
            continue
        excerpt = excerpt_fn(root, issue.file, issue.line)
        if not excerpt:
            continue
        done.add(issue.file)
        lines.append("")
        lines.append(f"## Extrait de {issue.file} (autour de la ligne {issue.line})")
        lines.append("```cpp")
        lines.append(excerpt)
        lines.append("```")

    text = "\n".join(lines)
    if len(text) > max_chars:
        text = text[:max_chars] + "\n... (contexte tronque)"
    return text
