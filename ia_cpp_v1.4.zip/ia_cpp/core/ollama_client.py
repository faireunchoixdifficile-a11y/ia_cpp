"""Client Ollama minimaliste, sans dependance externe (urllib uniquement).

Couvre les trois besoins de l'application :
  - lister les modeles installes              -> GET  /api/tags
  - dialoguer en streaming                    -> POST /api/chat
  - calculer des embeddings pour le RAG       -> POST /api/embed (fallback /api/embeddings)
"""
from __future__ import annotations

import json
import threading
import urllib.error
import urllib.request
from typing import Iterator, Sequence


class OllamaError(RuntimeError):
    pass


class OllamaClient:
    def __init__(self, base_url: str = "http://localhost:11434", timeout: int = 900) -> None:
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout

    # ------------------------------------------------------------ interne
    def _request(self, path: str, payload: dict | None = None, method: str = "POST"):
        url = f"{self.base_url}{path}"
        data = json.dumps(payload).encode("utf-8") if payload is not None else None
        headers = {"Content-Type": "application/json"}
        req = urllib.request.Request(url, data=data, headers=headers, method=method)
        # un proxy systeme ne doit jamais intercepter un appel vers localhost
        opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))
        try:
            return opener.open(req, timeout=self.timeout)
        except urllib.error.HTTPError as exc:  # pragma: no cover - depend du serveur
            body = exc.read().decode("utf-8", "replace")[:500]
            raise OllamaError(f"HTTP {exc.code} sur {path} : {body}") from exc
        except urllib.error.URLError as exc:
            raise OllamaError(
                f"Ollama injoignable sur {self.base_url} ({exc.reason}). "
                "Verifie que le service est demarre."
            ) from exc

    def _json(self, path: str, payload: dict | None = None, method: str = "POST") -> dict:
        with self._request(path, payload, method) as resp:
            raw = resp.read().decode("utf-8", "replace")
        try:
            return json.loads(raw)
        except json.JSONDecodeError as exc:
            raise OllamaError(f"Reponse illisible de {path}") from exc

    # ------------------------------------------------------------- publics
    def ping(self) -> bool:
        try:
            self._request("/api/tags", method="GET").close()
            return True
        except OllamaError:
            return False

    def list_models(self) -> list[str]:
        data = self._json("/api/tags", method="GET")
        models = data.get("models") or []
        names = [m.get("name", "") for m in models if m.get("name")]
        return sorted(names)

    def chat_stream(
        self,
        model: str,
        messages: list[dict],
        options: dict | None = None,
        stop_event: threading.Event | None = None,
    ) -> Iterator[str]:
        """Rend les fragments de texte au fil de la generation."""
        payload = {
            "model": model,
            "messages": messages,
            "stream": True,
            "options": options or {},
        }
        with self._request("/api/chat", payload) as resp:
            for raw_line in resp:
                if stop_event is not None and stop_event.is_set():
                    break
                line = raw_line.decode("utf-8", "replace").strip()
                if not line:
                    continue
                try:
                    chunk = json.loads(line)
                except json.JSONDecodeError:
                    continue
                if chunk.get("error"):
                    raise OllamaError(str(chunk["error"]))
                piece = (chunk.get("message") or {}).get("content", "")
                if piece:
                    yield piece
                if chunk.get("done"):
                    break

    def chat(self, model: str, messages: list[dict], options: dict | None = None) -> str:
        payload = {
            "model": model,
            "messages": messages,
            "stream": False,
            "options": options or {},
        }
        data = self._json("/api/chat", payload)
        if data.get("error"):
            raise OllamaError(str(data["error"]))
        return (data.get("message") or {}).get("content", "")

    def embed(self, model: str, texts: Sequence[str]) -> list[list[float]]:
        """Retourne un vecteur par texte. Gere les deux API d'Ollama."""
        if not texts:
            return []
        try:
            data = self._json("/api/embed", {"model": model, "input": list(texts)})
            vectors = data.get("embeddings")
            if vectors:
                return [list(map(float, v)) for v in vectors]
        except OllamaError:
            pass  # serveur plus ancien : on bascule sur l'ancienne route
        results: list[list[float]] = []
        for text in texts:
            data = self._json("/api/embeddings", {"model": model, "prompt": text})
            vector = data.get("embedding")
            if not vector:
                raise OllamaError(
                    f"Le modele '{model}' ne renvoie pas d'embedding. "
                    "Installe-le avec : ollama pull nomic-embed-text"
                )
            results.append([float(x) for x in vector])
        return results
