"""Ecriture securisee dans le dossier projet + manifeste de l'arborescence.

Regles non negociables :
  - aucun chemin absolu, aucun '..' : tout est confine sous la racine du projet
  - extension ou nom de fichier obligatoirement dans la liste autorisee
  - sauvegarde horodatee de l'ancienne version avant tout ecrasement
"""
from __future__ import annotations

import difflib
import hashlib
import re
import shutil
import time
from dataclasses import dataclass
from pathlib import Path

WORK_DIR_NAME = ".ia_cpp"
SKIP_DIRS = {
    ".git", ".svn", ".hg", ".vs", ".vscode", ".idea", "build", "out", "bin", "obj",
    "cmake-build-debug", "cmake-build-release", "x64", "Debug", "Release",
    "node_modules", "__pycache__", WORK_DIR_NAME, "vcpkg_installed", "_deps",
}


class WriteRefused(Exception):
    pass


@dataclass
class ApplyResult:
    path: str
    action: str
    ok: bool
    message: str = ""
    sha256: str = ""
    backup: str = ""
    size: int = 0


def sha256_text(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def work_dir(root: Path) -> Path:
    path = Path(root) / WORK_DIR_NAME
    path.mkdir(parents=True, exist_ok=True)
    return path


def backup_dir(root: Path) -> Path:
    path = work_dir(root) / "backups"
    path.mkdir(parents=True, exist_ok=True)
    return path


def safe_join(root: Path | str, rel_path: str) -> Path:
    """Resout rel_path sous root, ou leve WriteRefused."""
    root_resolved = Path(root).resolve()
    candidate = (root_resolved / rel_path).resolve()
    try:
        candidate.relative_to(root_resolved)
    except ValueError as exc:
        raise WriteRefused(
            f"Chemin hors du dossier projet refuse : {rel_path}"
        ) from exc
    if WORK_DIR_NAME in candidate.parts:
        raise WriteRefused(f"Ecriture interdite dans {WORK_DIR_NAME}/ : {rel_path}")
    return candidate


def is_allowed(rel_path: str, allowed_ext: list[str], allowed_names: list[str]) -> tuple[bool, str]:
    name = Path(rel_path).name
    if not name:
        return False, "nom de fichier vide"
    if name in allowed_names:
        return True, ""
    suffix = Path(name).suffix.lower()
    if suffix in [e.lower() for e in allowed_ext]:
        return True, ""
    return False, f"extension '{suffix or name}' non autorisee"


def read_text(path: Path) -> str:
    for encoding in ("utf-8", "utf-8-sig", "cp1252", "latin-1"):
        try:
            return path.read_text(encoding=encoding)
        except (UnicodeDecodeError, LookupError):
            continue
    return path.read_bytes().decode("utf-8", "replace")


def preview_diff(root: Path, rel_path: str, new_content: str, action: str) -> str:
    target = Path(root) / rel_path
    old = read_text(target) if target.exists() and target.is_file() else ""
    if action == "delete":
        new_content = ""
    diff = difflib.unified_diff(
        old.splitlines(keepends=True),
        new_content.splitlines(keepends=True),
        fromfile=f"a/{rel_path}" + ("" if old else " (nouveau)"),
        tofile=f"b/{rel_path}" + (" (supprime)" if action == "delete" else ""),
        n=3,
    )
    text = "".join(diff)
    return text or "(aucune modification : contenu identique)\n"


def diff_stats(root: Path, rel_path: str, new_content: str, action: str) -> tuple[int, int]:
    target = Path(root) / rel_path
    old = read_text(target).splitlines() if target.exists() and target.is_file() else []
    new = [] if action == "delete" else new_content.splitlines()
    added = removed = 0
    for line in difflib.ndiff(old, new):
        if line.startswith("+ "):
            added += 1
        elif line.startswith("- "):
            removed += 1
    return added, removed


def apply_op(root: Path | str, rel_path: str, action: str, content: str,
             allowed_ext: list[str], allowed_names: list[str],
             make_backup: bool = True, max_bytes: int = 400_000) -> ApplyResult:
    root = Path(root)
    try:
        target = safe_join(root, rel_path)
    except WriteRefused as exc:
        return ApplyResult(rel_path, action, False, str(exc))

    ok, reason = is_allowed(rel_path, allowed_ext, allowed_names)
    if not ok:
        return ApplyResult(rel_path, action, False, f"refuse : {reason}")

    data = content.encode("utf-8")
    if action != "delete" and len(data) > max_bytes:
        return ApplyResult(rel_path, action, False,
                           f"refuse : fichier trop volumineux ({len(data)} octets)")

    backup_rel = ""
    if target.exists() and target.is_file() and make_backup:
        stamp = time.strftime("%Y%m%d-%H%M%S")
        dest = backup_dir(root) / stamp / rel_path
        dest.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(target, dest)
        backup_rel = str(dest.relative_to(root)).replace("\\", "/")

    try:
        if action == "delete":
            if target.exists():
                target.unlink()
                return ApplyResult(rel_path, action, True, "supprime", backup=backup_rel)
            return ApplyResult(rel_path, action, True, "deja absent", backup=backup_rel)

        target.parent.mkdir(parents=True, exist_ok=True)
        with open(target, "w", encoding="utf-8", newline="\n") as handle:
            handle.write(content)
    except OSError as exc:
        return ApplyResult(rel_path, action, False, f"erreur disque : {exc}", backup=backup_rel)

    return ApplyResult(
        rel_path, action, True, "ecrit",
        sha256=sha256_text(content), backup=backup_rel, size=len(data),
    )


def restore_backup(root: Path | str, backup_rel: str, rel_path: str) -> bool:
    root = Path(root)
    source = root / backup_rel
    if not source.exists():
        return False
    target = safe_join(root, rel_path)
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(source, target)
    return True


# --------------------------------------------------------------- manifeste

_DECL_RE = re.compile(
    r"^\s*(?:template\s*<[^>]*>\s*)?"
    r"(?:(?:class|struct|enum(?:\s+class)?|namespace|union)\s+[A-Za-z_]\w*"
    r"|[A-Za-z_][\w:<>,\s\*&]*\s+[A-Za-z_]\w*\s*\([^;{]*\))",
    re.MULTILINE,
)
_INCLUDE_RE = re.compile(r'^\s*#\s*include\s+([<"][^>"]+[>"])', re.MULTILINE)


def _signature(path: Path, max_items: int = 14) -> list[str]:
    try:
        text = read_text(path)
    except OSError:
        return []
    items: list[str] = []
    for match in _INCLUDE_RE.finditer(text):
        items.append(f"#include {match.group(1)}")
        if len(items) >= 6:
            break
    for match in _DECL_RE.finditer(text):
        line = " ".join(match.group(0).split())
        if len(line) > 110:
            line = line[:107] + "..."
        if line not in items:
            items.append(line)
        if len(items) >= max_items:
            break
    return items


def scan_project(root: Path | str, allowed_ext: list[str], allowed_names: list[str],
                 max_files: int = 150) -> list[dict]:
    root = Path(root)
    if not root.exists():
        return []
    entries: list[dict] = []
    allowed_lower = [e.lower() for e in allowed_ext]
    for path in sorted(root.rglob("*")):
        if len(entries) >= max_files:
            break
        if path.is_dir():
            continue
        if any(part in SKIP_DIRS for part in path.relative_to(root).parts[:-1]):
            continue
        name = path.name
        if name not in allowed_names and path.suffix.lower() not in allowed_lower:
            continue
        rel = str(path.relative_to(root)).replace("\\", "/")
        try:
            size = path.stat().st_size
        except OSError:
            continue
        entries.append({"path": rel, "size": size, "suffix": path.suffix.lower()})
    return entries


def build_manifest(root: Path | str, allowed_ext: list[str], allowed_names: list[str],
                   max_files: int = 150, with_signatures: bool = True) -> str:
    root = Path(root)
    entries = scan_project(root, allowed_ext, allowed_names, max_files)
    if not entries:
        return "(dossier projet vide : aucun fichier source present)"
    lines = [f"Racine : {root}", f"{len(entries)} fichier(s) source suivis :"]
    for entry in entries:
        lines.append(f"  - {entry['path']} ({entry['size']} o)")
    if with_signatures:
        header_ext = {".h", ".hpp", ".hxx", ".hh", ".ipp", ".inl"}
        lines.append("")
        lines.append("Declarations principales :")
        shown = 0
        for entry in entries:
            if shown >= 25:
                break
            if entry["suffix"] not in header_ext and entry["suffix"] not in {".cpp", ".cc", ".cxx"}:
                continue
            signature = _signature(root / entry["path"])
            if not signature:
                continue
            lines.append(f"  {entry['path']}")
            for item in signature:
                lines.append(f"      {item}")
            shown += 1
    return "\n".join(lines)


def excerpt_around(root: Path | str, rel_path: str, line: int, radius: int = 18) -> str:
    target = Path(root) / rel_path
    if not target.exists() or not target.is_file():
        return ""
    try:
        lines = read_text(target).splitlines()
    except OSError:
        return ""
    if line <= 0:
        start, end = 0, min(len(lines), radius * 2)
    else:
        start = max(0, line - radius - 1)
        end = min(len(lines), line + radius)
    numbered = [f"{idx + 1:5d} | {lines[idx]}" for idx in range(start, end)]
    return "\n".join(numbered)


def read_project_file(root: Path | str, rel_path: str, max_chars: int = 20000) -> str:
    target = Path(root) / rel_path
    if not target.exists() or not target.is_file():
        return ""
    text = read_text(target)
    if len(text) > max_chars:
        return text[:max_chars] + f"\n... (tronque, {len(text)} caracteres au total)"
    return text


# ------------------------------------------------- contenu reel des sources

def _extract_paths(text: str) -> list[str]:
    """Chemins de fichiers cites dans un texte libre (prompt, erreurs)."""
    pattern = re.compile(
        r"(?:[\w.\-]+/)*[\w.\-]+\.(?:cpp|cc|cxx|c|h|hpp|hxx|hh|ipp|inl|cmake|txt|md|json)",
        re.IGNORECASE)
    found = []
    for match in pattern.finditer(text.replace("\\", "/")):
        value = match.group(0)
        if value not in found:
            found.append(value)
    if re.search(r"\bCMakeLists\.txt\b", text, re.IGNORECASE) and "CMakeLists.txt" not in found:
        found.append("CMakeLists.txt")
    return found


def collect_sources(root: Path | str, allowed_ext: list[str], allowed_names: list[str],
                    priority: list[str] | None = None, max_chars: int = 14000,
                    max_files: int = 14) -> tuple[list[tuple[str, str]], list[str]]:
    """Retourne (fichiers inclus, fichiers ecartes faute de place).

    Les fichiers cites dans la demande passent en premier, puis les plus
    petits : mieux vaut cinq fichiers entiers qu'un seul tronque, car un
    fichier tronque pousse le modele a le reecrire de memoire.
    """
    root = Path(root)
    entries = scan_project(root, allowed_ext, allowed_names, max_files * 6)
    by_path = {entry["path"]: entry for entry in entries}

    ordered: list[str] = []
    for wanted in (priority or []):
        key = wanted.replace("\\", "/").lstrip("./")
        if key in by_path and key not in ordered:
            ordered.append(key)
        else:  # citation partielle : "csv_reader.cpp" pour "csv/csv_reader.cpp"
            for path in by_path:
                if path.endswith("/" + key) and path not in ordered:
                    ordered.append(path)
                    break
    for path in sorted(by_path, key=lambda p: by_path[p]["size"]):
        if path not in ordered:
            ordered.append(path)

    included: list[tuple[str, str]] = []
    skipped: list[str] = []
    total = 0
    for path in ordered:
        if len(included) >= max_files:
            skipped.append(path)
            continue
        try:
            content = read_text(root / path)
        except OSError:
            continue
        if total + len(content) > max_chars and included:
            skipped.append(path)
            continue
        included.append((path, content))
        total += len(content)
    return included, skipped


def format_sources(sources: list[tuple[str, str]], skipped: list[str]) -> str:
    """Mise en forme sans balises markdown, pour ne pas inspirer le modele."""
    if not sources:
        return ""
    blocks: list[str] = []
    for path, content in sources:
        body = content if content.endswith("\n") else content + "\n"
        blocks.append(f"----- DEBUT {path} -----\n{body}----- FIN {path} -----")
    text = "\n\n".join(blocks)
    if skipped:
        text += ("\n\nFichiers non inclus faute de place : " + ", ".join(skipped)
                 + ".\nDemande explicitement leur contenu si tu dois les modifier ; "
                   "ne les reecris pas de memoire.")
    return text
