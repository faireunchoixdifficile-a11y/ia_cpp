"""Base de savoirs : decoupage, embeddings, recherche par similarite cosinus.

Le corpus reste petit (quelques milliers d'extraits au maximum), la recherche
exhaustive en Python pur est donc suffisante et evite toute dependance
(pas de numpy, pas de base vectorielle).
"""
from __future__ import annotations

import hashlib
import math
import re
from dataclasses import dataclass
from pathlib import Path

from .db import Database, unpack_vector
from .ollama_client import OllamaClient, OllamaError

HEADING_RE = re.compile(r"^(#{1,6})\s+(.*)$", re.MULTILINE)


@dataclass
class Hit:
    pack_name: str
    title: str
    content: str
    score: float


def estimate_tokens(text: str) -> int:
    """Approximation suffisante pour un budget de contexte (~3,6 car/token)."""
    return max(1, int(len(text) / 3.6))


def file_hash(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()[:16]


def split_markdown(text: str, max_chars: int = 1600, overlap: int = 180) -> list[dict]:
    """Decoupe par titres markdown, puis par taille si une section est longue."""
    matches = list(HEADING_RE.finditer(text))
    sections: list[tuple[str, str]] = []
    if not matches:
        sections.append(("", text))
    else:
        if matches[0].start() > 0:
            head = text[: matches[0].start()].strip()
            if head:
                sections.append(("Introduction", head))
        for index, match in enumerate(matches):
            title = match.group(2).strip()
            start = match.end()
            end = matches[index + 1].start() if index + 1 < len(matches) else len(text)
            body = text[start:end].strip()
            if body:
                sections.append((title, body))

    chunks: list[dict] = []
    for title, body in sections:
        if len(body) <= max_chars:
            chunks.append({"title": title, "content": body})
            continue
        start = 0
        part = 1
        while start < len(body):
            end = min(len(body), start + max_chars)
            if end < len(body):
                cut = body.rfind("\n", start + max_chars // 2, end)
                if cut > start:
                    end = cut
            piece = body[start:end].strip()
            if piece:
                chunks.append({"title": f"{title} ({part})" if title else f"partie {part}",
                               "content": piece})
            part += 1
            start = max(end - overlap, end) if end >= len(body) else end - overlap
            if start < 0:
                start = 0
    for chunk in chunks:
        chunk["tokens_est"] = estimate_tokens(chunk["content"])
    return [c for c in chunks if len(c["content"]) > 40]


def cosine(a: list[float], b: list[float]) -> float:
    if not a or not b or len(a) != len(b):
        return 0.0
    dot = norm_a = norm_b = 0.0
    for x, y in zip(a, b):
        dot += x * y
        norm_a += x * x
        norm_b += y * y
    if norm_a <= 0.0 or norm_b <= 0.0:
        return 0.0
    return dot / (math.sqrt(norm_a) * math.sqrt(norm_b))


_WORD_RE = re.compile(r"[A-Za-z_][A-Za-z0-9_:]{2,}")


def keyword_score(query: str, text: str) -> float:
    """Repli lexical quand les embeddings ne sont pas disponibles."""
    words = {w.lower() for w in _WORD_RE.findall(query)}
    if not words:
        return 0.0
    lowered = text.lower()
    hits = sum(1 for w in words if w in lowered)
    return hits / len(words)


class KnowledgeBase:
    def __init__(self, db: Database, client: OllamaClient, embed_model: str) -> None:
        self.db = db
        self.client = client
        self.embed_model = embed_model

    # ----------------------------------------------------------- ingestion
    def ingest_file(self, path: Path, progress=None, force: bool = False) -> dict:
        path = Path(path)
        text = path.read_text(encoding="utf-8", errors="replace")
        digest = file_hash(path)
        name = path.stem.replace("_", " ")
        first_line = text.strip().splitlines()[0] if text.strip() else ""
        description = first_line.lstrip("# ").strip()[:200]

        existing = self.db.query_one("SELECT * FROM knowledge_packs WHERE source=?", (str(path),))
        if existing and existing["source_hash"] == digest and not force \
                and existing["embed_model"] == self.embed_model and existing["chunks"] > 0:
            return {"pack": name, "status": "inchange", "chunks": int(existing["chunks"])}

        pack_id = self.db.upsert_pack(name, description, str(path), digest, self.embed_model)
        self.db.clear_pack_chunks(pack_id)

        chunks = split_markdown(text)
        if progress:
            progress(f"{name} : {len(chunks)} extrait(s) a indexer")

        batch_size = 16
        embedded = 0
        for start in range(0, len(chunks), batch_size):
            batch = chunks[start:start + batch_size]
            try:
                vectors = self.client.embed(self.embed_model, [c["content"] for c in batch])
            except OllamaError as exc:
                if progress:
                    progress(f"{name} : embeddings indisponibles ({exc}). "
                             "Indexation lexicale seule.")
                vectors = [[] for _ in batch]
            for chunk, vector in zip(batch, vectors):
                chunk["embedding"] = vector
            self.db.add_chunks(pack_id, batch)
            embedded += len(batch)
            if progress:
                progress(f"{name} : {embedded}/{len(chunks)}")
        return {"pack": name, "status": "indexe", "chunks": len(chunks)}

    def ingest_directory(self, directory: Path, progress=None, force: bool = False) -> list[dict]:
        results = []
        for path in sorted(Path(directory).glob("*.md")):
            results.append(self.ingest_file(path, progress=progress, force=force))
        for path in sorted(Path(directory).glob("*.txt")):
            results.append(self.ingest_file(path, progress=progress, force=force))
        return results

    # ------------------------------------------------------------ recherche
    def search(self, query: str, pack_ids: list[int], top_k: int = 5) -> list[Hit]:
        rows = self.db.chunks_for_packs(pack_ids)
        if not rows:
            return []
        query_vector: list[float] = []
        try:
            vectors = self.client.embed(self.embed_model, [query])
            query_vector = vectors[0] if vectors else []
        except OllamaError:
            query_vector = []

        scored: list[Hit] = []
        for row in rows:
            content = row["content"]
            if query_vector:
                score = cosine(query_vector, unpack_vector(row["embedding"]))
                if score <= 0.0:
                    score = keyword_score(query, content) * 0.5
            else:
                score = keyword_score(query, f"{row['title']} {content}")
            if score > 0.0:
                scored.append(Hit(row["pack_name"], row["title"], content, score))
        scored.sort(key=lambda hit: hit.score, reverse=True)
        return scored[:top_k]

    def format_hits(self, hits: list[Hit], max_chars: int = 4500) -> str:
        if not hits:
            return ""
        blocks: list[str] = []
        total = 0
        for hit in hits:
            header = f"### [{hit.pack_name}] {hit.title or 'extrait'} (pertinence {hit.score:.2f})"
            block = f"{header}\n{hit.content.strip()}"
            if total + len(block) > max_chars:
                break
            blocks.append(block)
            total += len(block)
        return "\n\n".join(blocks)

    def stats(self) -> list[dict]:
        return [
            {
                "id": int(row["id"]),
                "name": row["name"],
                "description": row["description"],
                "chunks": int(row["chunks"]),
                "embed_model": row["embed_model"],
                "source": row["source"],
            }
            for row in self.db.list_packs()
        ]
