"""Integration Git facultative : un commit par generation acceptee.

Si git n'est pas installe ou si l'option est desactivee, toutes les
fonctions deviennent des no-op silencieux : l'application reste utilisable.
"""
from __future__ import annotations

import shutil
import subprocess
from pathlib import Path

GITIGNORE = """# genere par IA C++
build/
out/
bin/
obj/
cmake-build-*/
x64/
Debug/
Release/
*.obj
*.o
*.exe
*.pdb
*.ilk
*.lib
*.dll
*.user
.vs/
.vscode/
.idea/
.ia_cpp/backups/
CMakeCache.txt
CMakeFiles/
"""


def git_available() -> bool:
    return shutil.which("git") is not None


def _run(args: list[str], cwd: Path, timeout: int = 60) -> tuple[int, str]:
    try:
        proc = subprocess.run(
            ["git", *args],
            cwd=str(cwd),
            capture_output=True,
            text=True,
            timeout=timeout,
            encoding="utf-8",
            errors="replace",
        )
        return proc.returncode, (proc.stdout or "") + (proc.stderr or "")
    except (OSError, subprocess.SubprocessError) as exc:
        return 1, str(exc)


def is_repo(root: Path | str) -> bool:
    if not git_available():
        return False
    code, _ = _run(["rev-parse", "--is-inside-work-tree"], Path(root))
    return code == 0


def ensure_repo(root: Path | str) -> tuple[bool, str]:
    root = Path(root)
    if not git_available():
        return False, "git introuvable dans le PATH"
    if not root.exists():
        return False, "dossier projet inexistant"
    if is_repo(root):
        return True, "depot existant"
    code, out = _run(["init"], root)
    if code != 0:
        return False, f"git init a echoue : {out.strip()[:200]}"
    gitignore = root / ".gitignore"
    if not gitignore.exists():
        gitignore.write_text(GITIGNORE, encoding="utf-8")
    _run(["add", "-A"], root)
    _run(["commit", "-m", "Etat initial avant intervention de l'IA"], root)
    return True, "depot initialise"


def commit(root: Path | str, message: str, paths: list[str] | None = None) -> tuple[bool, str]:
    root = Path(root)
    if not git_available() or not is_repo(root):
        return False, "pas de depot git"
    if paths:
        code, out = _run(["add", "--", *paths], root)
    else:
        code, out = _run(["add", "-A"], root)
    if code != 0:
        return False, out.strip()[:300]
    code, out = _run(["commit", "-m", message], root)
    if code != 0:
        if "nothing to commit" in out.lower():
            return True, "rien a committer"
        return False, out.strip()[:300]
    return True, out.strip()[:300]


def head_short(root: Path | str) -> str:
    if not git_available() or not is_repo(root):
        return ""
    code, out = _run(["rev-parse", "--short", "HEAD"], Path(root))
    return out.strip() if code == 0 else ""


def status_short(root: Path | str) -> str:
    if not git_available() or not is_repo(root):
        return ""
    code, out = _run(["status", "--short"], Path(root))
    return out.strip() if code == 0 else ""


def log_recent(root: Path | str, count: int = 15) -> str:
    if not git_available() or not is_repo(root):
        return ""
    code, out = _run(["log", f"-{count}", "--oneline", "--no-decorate"], Path(root))
    return out.strip() if code == 0 else ""


def revert_last(root: Path | str) -> tuple[bool, str]:
    """Annule le dernier commit en restaurant l'etat precedent du disque."""
    root = Path(root)
    if not git_available() or not is_repo(root):
        return False, "pas de depot git"
    code, out = _run(["reset", "--hard", "HEAD~1"], root)
    if code != 0:
        return False, out.strip()[:300]
    return True, "retour au commit precedent effectue"
