"""Couche d'acces SQLite : projets, conversations, fichiers, erreurs, savoirs.

Un seul fichier de base, versionne par PRAGMA user_version pour pouvoir
faire evoluer le schema sans perdre l'historique.
"""
from __future__ import annotations

import json
import sqlite3
import threading
import time
from array import array
from pathlib import Path
from typing import Any, Iterable, Sequence

MIGRATIONS: list[list[str]] = [
    # --- version 1 : schema initial -------------------------------------
    [
        """
        CREATE TABLE projects (
            id            INTEGER PRIMARY KEY AUTOINCREMENT,
            name          TEXT NOT NULL UNIQUE,
            path          TEXT NOT NULL,
            cpp_standard  TEXT NOT NULL DEFAULT 'c++20',
            compiler      TEXT NOT NULL DEFAULT 'MSVC',
            platform      TEXT NOT NULL DEFAULT 'Windows',
            build_system  TEXT NOT NULL DEFAULT 'CMake',
            style_notes   TEXT NOT NULL DEFAULT '',
            system_prompt TEXT NOT NULL DEFAULT '',
            created_at    REAL NOT NULL,
            updated_at    REAL NOT NULL
        )
        """,
        """
        CREATE TABLE conversations (
            id         INTEGER PRIMARY KEY AUTOINCREMENT,
            project_id INTEGER NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
            title      TEXT NOT NULL DEFAULT 'Nouvelle conversation',
            created_at REAL NOT NULL,
            updated_at REAL NOT NULL
        )
        """,
        """
        CREATE TABLE messages (
            id              INTEGER PRIMARY KEY AUTOINCREMENT,
            conversation_id INTEGER NOT NULL REFERENCES conversations(id) ON DELETE CASCADE,
            role            TEXT NOT NULL,
            content         TEXT NOT NULL,
            model           TEXT NOT NULL DEFAULT '',
            tokens_est      INTEGER NOT NULL DEFAULT 0,
            meta            TEXT NOT NULL DEFAULT '{}',
            created_at      REAL NOT NULL
        )
        """,
        "CREATE INDEX idx_messages_conv ON messages(conversation_id, id)",
        """
        CREATE TABLE summaries (
            id               INTEGER PRIMARY KEY AUTOINCREMENT,
            conversation_id  INTEGER NOT NULL REFERENCES conversations(id) ON DELETE CASCADE,
            content          TEXT NOT NULL,
            up_to_message_id INTEGER NOT NULL DEFAULT 0,
            created_at       REAL NOT NULL
        )
        """,
        """
        CREATE TABLE generated_files (
            id         INTEGER PRIMARY KEY AUTOINCREMENT,
            project_id INTEGER NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
            message_id INTEGER NOT NULL DEFAULT 0,
            rel_path   TEXT NOT NULL,
            action     TEXT NOT NULL,
            sha256     TEXT NOT NULL DEFAULT '',
            version    INTEGER NOT NULL DEFAULT 1,
            backup     TEXT NOT NULL DEFAULT '',
            bytes      INTEGER NOT NULL DEFAULT 0,
            created_at REAL NOT NULL
        )
        """,
        "CREATE INDEX idx_genfiles_project ON generated_files(project_id, rel_path)",
        """
        CREATE TABLE build_errors (
            id         INTEGER PRIMARY KEY AUTOINCREMENT,
            project_id INTEGER NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
            message_id INTEGER NOT NULL DEFAULT 0,
            raw_text   TEXT NOT NULL,
            file       TEXT NOT NULL DEFAULT '',
            line       INTEGER NOT NULL DEFAULT 0,
            col        INTEGER NOT NULL DEFAULT 0,
            kind       TEXT NOT NULL DEFAULT 'error',
            code       TEXT NOT NULL DEFAULT '',
            text       TEXT NOT NULL DEFAULT '',
            resolved   INTEGER NOT NULL DEFAULT 0,
            created_at REAL NOT NULL
        )
        """,
        """
        CREATE TABLE knowledge_packs (
            id          INTEGER PRIMARY KEY AUTOINCREMENT,
            name        TEXT NOT NULL UNIQUE,
            description TEXT NOT NULL DEFAULT '',
            source      TEXT NOT NULL DEFAULT '',
            source_hash TEXT NOT NULL DEFAULT '',
            enabled     INTEGER NOT NULL DEFAULT 1,
            chunks      INTEGER NOT NULL DEFAULT 0,
            embed_model TEXT NOT NULL DEFAULT '',
            created_at  REAL NOT NULL,
            updated_at  REAL NOT NULL
        )
        """,
        """
        CREATE TABLE knowledge_chunks (
            id         INTEGER PRIMARY KEY AUTOINCREMENT,
            pack_id    INTEGER NOT NULL REFERENCES knowledge_packs(id) ON DELETE CASCADE,
            title      TEXT NOT NULL DEFAULT '',
            content    TEXT NOT NULL,
            tokens_est INTEGER NOT NULL DEFAULT 0,
            embedding  BLOB,
            created_at REAL NOT NULL
        )
        """,
        "CREATE INDEX idx_chunks_pack ON knowledge_chunks(pack_id)",
        """
        CREATE TABLE project_packs (
            project_id INTEGER NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
            pack_id    INTEGER NOT NULL REFERENCES knowledge_packs(id) ON DELETE CASCADE,
            enabled    INTEGER NOT NULL DEFAULT 1,
            PRIMARY KEY (project_id, pack_id)
        )
        """,
        """
        CREATE TABLE settings (
            key   TEXT PRIMARY KEY,
            value TEXT NOT NULL
        )
        """,
    ],
]


def pack_vector(vec: Sequence[float]) -> bytes:
    return array("f", vec).tobytes()


def unpack_vector(blob: bytes | None) -> list[float]:
    if not blob:
        return []
    arr = array("f")
    arr.frombytes(blob)
    return list(arr)


class Database:
    """Wrapper SQLite thread-safe (un verrou, une connexion partagee)."""

    def __init__(self, path: Path | str) -> None:
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._lock = threading.RLock()
        self._conn = sqlite3.connect(str(self.path), check_same_thread=False)
        self._conn.row_factory = sqlite3.Row
        self._conn.execute("PRAGMA journal_mode=WAL")
        self._conn.execute("PRAGMA foreign_keys=ON")
        self.migrate()

    # ------------------------------------------------------------ interne
    def close(self) -> None:
        with self._lock:
            self._conn.close()

    def execute(self, sql: str, params: Iterable = ()) -> sqlite3.Cursor:
        with self._lock:
            cur = self._conn.execute(sql, tuple(params))
            self._conn.commit()
            return cur

    def executemany(self, sql: str, seq: Iterable[Sequence]) -> None:
        with self._lock:
            self._conn.executemany(sql, [tuple(s) for s in seq])
            self._conn.commit()

    def query(self, sql: str, params: Iterable = ()) -> list[sqlite3.Row]:
        with self._lock:
            return list(self._conn.execute(sql, tuple(params)).fetchall())

    def query_one(self, sql: str, params: Iterable = ()) -> sqlite3.Row | None:
        rows = self.query(sql, params)
        return rows[0] if rows else None

    def migrate(self) -> None:
        with self._lock:
            version = self._conn.execute("PRAGMA user_version").fetchone()[0]
            for index, statements in enumerate(MIGRATIONS, start=1):
                if version >= index:
                    continue
                for statement in statements:
                    self._conn.execute(statement)
                self._conn.execute(f"PRAGMA user_version={index}")
                self._conn.commit()
                version = index

    # ----------------------------------------------------------- projets
    def create_project(self, name: str, path: str, **kwargs) -> int:
        now = time.time()
        fields = {
            "cpp_standard": kwargs.get("cpp_standard", "c++20"),
            "compiler": kwargs.get("compiler", "MSVC"),
            "platform": kwargs.get("platform", "Windows"),
            "build_system": kwargs.get("build_system", "CMake"),
            "style_notes": kwargs.get("style_notes", ""),
            "system_prompt": kwargs.get("system_prompt", ""),
        }
        cur = self.execute(
            """INSERT INTO projects
               (name, path, cpp_standard, compiler, platform, build_system,
                style_notes, system_prompt, created_at, updated_at)
               VALUES (?,?,?,?,?,?,?,?,?,?)""",
            (name, path, fields["cpp_standard"], fields["compiler"], fields["platform"],
             fields["build_system"], fields["style_notes"], fields["system_prompt"], now, now),
        )
        project_id = int(cur.lastrowid)
        # tous les packs disponibles sont actifs par defaut sur un nouveau projet
        for pack in self.list_packs():
            self.set_project_pack(project_id, int(pack["id"]), True)
        return project_id

    def update_project(self, project_id: int, **fields) -> None:
        allowed = {"name", "path", "cpp_standard", "compiler", "platform",
                   "build_system", "style_notes", "system_prompt"}
        sets, values = [], []
        for key, value in fields.items():
            if key in allowed:
                sets.append(f"{key}=?")
                values.append(value)
        if not sets:
            return
        sets.append("updated_at=?")
        values.extend([time.time(), project_id])
        self.execute(f"UPDATE projects SET {', '.join(sets)} WHERE id=?", values)

    def list_projects(self) -> list[sqlite3.Row]:
        return self.query("SELECT * FROM projects ORDER BY updated_at DESC")

    def get_project(self, project_id: int) -> sqlite3.Row | None:
        return self.query_one("SELECT * FROM projects WHERE id=?", (project_id,))

    def delete_project(self, project_id: int) -> None:
        self.execute("DELETE FROM projects WHERE id=?", (project_id,))

    # ----------------------------------------------- conversations / messages
    def create_conversation(self, project_id: int, title: str = "Nouvelle conversation") -> int:
        now = time.time()
        cur = self.execute(
            "INSERT INTO conversations (project_id, title, created_at, updated_at) VALUES (?,?,?,?)",
            (project_id, title, now, now),
        )
        return int(cur.lastrowid)

    def list_conversations(self, project_id: int) -> list[sqlite3.Row]:
        return self.query(
            "SELECT * FROM conversations WHERE project_id=? ORDER BY updated_at DESC",
            (project_id,),
        )

    def rename_conversation(self, conversation_id: int, title: str) -> None:
        self.execute("UPDATE conversations SET title=?, updated_at=? WHERE id=?",
                     (title, time.time(), conversation_id))

    def delete_conversation(self, conversation_id: int) -> None:
        self.execute("DELETE FROM conversations WHERE id=?", (conversation_id,))

    def add_message(self, conversation_id: int, role: str, content: str,
                    model: str = "", tokens_est: int = 0, meta: dict | None = None) -> int:
        now = time.time()
        cur = self.execute(
            """INSERT INTO messages (conversation_id, role, content, model, tokens_est, meta, created_at)
               VALUES (?,?,?,?,?,?,?)""",
            (conversation_id, role, content, model, tokens_est,
             json.dumps(meta or {}, ensure_ascii=False), now),
        )
        self.execute("UPDATE conversations SET updated_at=? WHERE id=?", (now, conversation_id))
        row = self.query_one("SELECT project_id FROM conversations WHERE id=?", (conversation_id,))
        if row:
            self.execute("UPDATE projects SET updated_at=? WHERE id=?", (now, row["project_id"]))
        return int(cur.lastrowid)

    def list_messages(self, conversation_id: int, after_id: int = 0) -> list[sqlite3.Row]:
        return self.query(
            "SELECT * FROM messages WHERE conversation_id=? AND id>? ORDER BY id",
            (conversation_id, after_id),
        )

    def count_messages(self, conversation_id: int) -> int:
        row = self.query_one("SELECT COUNT(*) AS n FROM messages WHERE conversation_id=?",
                             (conversation_id,))
        return int(row["n"]) if row else 0

    # ----------------------------------------------------------- resumes
    def latest_summary(self, conversation_id: int) -> sqlite3.Row | None:
        return self.query_one(
            "SELECT * FROM summaries WHERE conversation_id=? ORDER BY id DESC LIMIT 1",
            (conversation_id,),
        )

    def add_summary(self, conversation_id: int, content: str, up_to_message_id: int) -> int:
        cur = self.execute(
            """INSERT INTO summaries (conversation_id, content, up_to_message_id, created_at)
               VALUES (?,?,?,?)""",
            (conversation_id, content, up_to_message_id, time.time()),
        )
        return int(cur.lastrowid)

    # --------------------------------------------------- fichiers generes
    def record_file(self, project_id: int, rel_path: str, action: str, sha256: str,
                    message_id: int = 0, backup: str = "", size: int = 0) -> int:
        row = self.query_one(
            "SELECT MAX(version) AS v FROM generated_files WHERE project_id=? AND rel_path=?",
            (project_id, rel_path),
        )
        version = int(row["v"] or 0) + 1
        cur = self.execute(
            """INSERT INTO generated_files
               (project_id, message_id, rel_path, action, sha256, version, backup, bytes, created_at)
               VALUES (?,?,?,?,?,?,?,?,?)""",
            (project_id, message_id, rel_path, action, sha256, version, backup, size, time.time()),
        )
        return int(cur.lastrowid)

    def list_files(self, project_id: int, limit: int = 500) -> list[sqlite3.Row]:
        return self.query(
            "SELECT * FROM generated_files WHERE project_id=? ORDER BY id DESC LIMIT ?",
            (project_id, limit),
        )

    def file_history(self, project_id: int, rel_path: str) -> list[sqlite3.Row]:
        return self.query(
            """SELECT * FROM generated_files WHERE project_id=? AND rel_path=?
               ORDER BY version DESC""",
            (project_id, rel_path),
        )

    # ------------------------------------------------- erreurs de build
    def add_build_errors(self, project_id: int, raw_text: str, parsed: list[dict],
                         message_id: int = 0) -> None:
        now = time.time()
        rows = [
            (project_id, message_id, raw_text, p.get("file", ""), int(p.get("line", 0)),
             int(p.get("col", 0)), p.get("kind", "error"), p.get("code", ""),
             p.get("text", ""), 0, now)
            for p in parsed
        ] or [(project_id, message_id, raw_text, "", 0, 0, "error", "", "", 0, now)]
        self.executemany(
            """INSERT INTO build_errors
               (project_id, message_id, raw_text, file, line, col, kind, code, text, resolved, created_at)
               VALUES (?,?,?,?,?,?,?,?,?,?,?)""",
            rows,
        )

    def open_errors(self, project_id: int) -> list[sqlite3.Row]:
        return self.query(
            "SELECT * FROM build_errors WHERE project_id=? AND resolved=0 ORDER BY id",
            (project_id,),
        )

    def resolve_errors(self, project_id: int) -> None:
        self.execute("UPDATE build_errors SET resolved=1 WHERE project_id=?", (project_id,))

    # ------------------------------------------------------------ savoirs
    def upsert_pack(self, name: str, description: str, source: str,
                    source_hash: str, embed_model: str) -> int:
        now = time.time()
        existing = self.query_one("SELECT * FROM knowledge_packs WHERE name=?", (name,))
        if existing:
            self.execute(
                """UPDATE knowledge_packs
                   SET description=?, source=?, source_hash=?, embed_model=?, updated_at=?
                   WHERE id=?""",
                (description, source, source_hash, embed_model, now, existing["id"]),
            )
            return int(existing["id"])
        cur = self.execute(
            """INSERT INTO knowledge_packs
               (name, description, source, source_hash, enabled, chunks, embed_model, created_at, updated_at)
               VALUES (?,?,?,?,1,0,?,?,?)""",
            (name, description, source, source_hash, embed_model, now, now),
        )
        pack_id = int(cur.lastrowid)
        for project in self.list_projects():
            self.set_project_pack(int(project["id"]), pack_id, True)
        return pack_id

    def list_packs(self) -> list[sqlite3.Row]:
        return self.query("SELECT * FROM knowledge_packs ORDER BY name")

    def get_pack(self, pack_id: int) -> sqlite3.Row | None:
        return self.query_one("SELECT * FROM knowledge_packs WHERE id=?", (pack_id,))

    def delete_pack(self, pack_id: int) -> None:
        self.execute("DELETE FROM knowledge_packs WHERE id=?", (pack_id,))

    def clear_pack_chunks(self, pack_id: int) -> None:
        self.execute("DELETE FROM knowledge_chunks WHERE pack_id=?", (pack_id,))
        self.execute("UPDATE knowledge_packs SET chunks=0 WHERE id=?", (pack_id,))

    def add_chunks(self, pack_id: int, chunks: list[dict]) -> None:
        now = time.time()
        self.executemany(
            """INSERT INTO knowledge_chunks (pack_id, title, content, tokens_est, embedding, created_at)
               VALUES (?,?,?,?,?,?)""",
            [(pack_id, c.get("title", ""), c["content"], int(c.get("tokens_est", 0)),
              pack_vector(c.get("embedding") or []), now) for c in chunks],
        )
        row = self.query_one("SELECT COUNT(*) AS n FROM knowledge_chunks WHERE pack_id=?", (pack_id,))
        self.execute("UPDATE knowledge_packs SET chunks=?, updated_at=? WHERE id=?",
                     (int(row["n"]) if row else 0, now, pack_id))

    def chunks_for_packs(self, pack_ids: Sequence[int]) -> list[sqlite3.Row]:
        if not pack_ids:
            return []
        marks = ",".join("?" for _ in pack_ids)
        return self.query(
            f"""SELECT c.id, c.pack_id, c.title, c.content, c.embedding, p.name AS pack_name
                FROM knowledge_chunks c JOIN knowledge_packs p ON p.id = c.pack_id
                WHERE c.pack_id IN ({marks})""",
            tuple(pack_ids),
        )

    def set_project_pack(self, project_id: int, pack_id: int, enabled: bool) -> None:
        self.execute(
            """INSERT INTO project_packs (project_id, pack_id, enabled) VALUES (?,?,?)
               ON CONFLICT(project_id, pack_id) DO UPDATE SET enabled=excluded.enabled""",
            (project_id, pack_id, 1 if enabled else 0),
        )

    def enabled_pack_ids(self, project_id: int) -> list[int]:
        rows = self.query(
            """SELECT p.id FROM knowledge_packs p
               LEFT JOIN project_packs pp ON pp.pack_id = p.id AND pp.project_id = ?
               WHERE p.enabled = 1 AND COALESCE(pp.enabled, 1) = 1""",
            (project_id,),
        )
        return [int(r["id"]) for r in rows]

    def project_pack_state(self, project_id: int) -> dict[int, bool]:
        rows = self.query(
            """SELECT p.id, COALESCE(pp.enabled, 1) AS enabled
               FROM knowledge_packs p
               LEFT JOIN project_packs pp ON pp.pack_id = p.id AND pp.project_id = ?""",
            (project_id,),
        )
        return {int(r["id"]): bool(r["enabled"]) for r in rows}

    # --------------------------------------------------------- parametres
    def set_setting(self, key: str, value: Any) -> None:
        self.execute(
            "INSERT INTO settings (key, value) VALUES (?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",
            (key, json.dumps(value, ensure_ascii=False)),
        )

    def get_setting(self, key: str, default=None):
        row = self.query_one("SELECT value FROM settings WHERE key=?", (key,))
        if not row:
            return default
        try:
            return json.loads(row["value"])
        except json.JSONDecodeError:
            return default
