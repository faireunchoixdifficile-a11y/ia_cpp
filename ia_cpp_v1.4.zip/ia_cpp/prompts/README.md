# Prompts systeme

- `system_code.md` : role et methode du modele de generation de code.
  Edite ce fichier pour changer le comportement global de l'IA ;
  il est relu a chaque requete, sans redemarrer l'application.

Le protocole d'ecriture de fichiers (`===FILE: ... ACTION: ...===`) est ajoute
automatiquement par l'application : ne le recopie pas ici.

Les consignes propres a un projet (bibliotheques imposees, conventions de
nommage, cible materielle) se saisissent dans la fiche du projet, pas ici.
