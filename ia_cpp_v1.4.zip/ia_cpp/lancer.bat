@echo off
rem Lancement de l'IA C++ locale sous Windows
cd /d "%~dp0"
where py >nul 2>nul && (py main.py & goto :eof)
python main.py
