# IA C++ locale

Interface Python/Tkinter pour piloter un modele Ollama local et lui faire
ecrire du code C++ directement dans un dossier projet, avec historique
persistant par projet, base de savoirs C++ interrogeable et boucle de
correction a partir des erreurs de compilation.

Aucune dependance Python externe. Tout est local : aucune donnee ne sort
de la machine.

## Installation

1. Installer Python 3.10+ avec tkinter (sous Windows, cocher
   « tcl/tk and IDLE » dans l'installeur).
2. Installer et demarrer [Ollama](https://ollama.com).
3. Recuperer les modeles :

       ollama pull qwen2.5-coder:7b
       ollama pull gemma4:e2b
       ollama pull nomic-embed-text

4. Verifier la liaison :

       python main.py --check

5. Indexer la base de savoirs C++ (une fois, puis a chaque ajout de document) :

       python main.py --index

6. Lancer l'interface :

       python main.py

   ou double-cliquer sur `lancer.bat` sous Windows.

## Cycle de travail

1. **Projet** : créer un projet (bouton `+`) en pointant le dossier qui
   recevra le code. Renseigner standard C++, compilateur, plateforme,
   conventions. Un depot git est initialise si git est disponible.
2. **Developpement** : ecrire la demande, `Ctrl+Entree` pour envoyer. La
   reponse arrive en flux.
3. **Revue** : chaque fichier propose est presente en diff, fichier par
   fichier. Decocher ce qu'on refuse, puis appliquer. Les fichiers sont
   ecrits et un commit git est cree.
4. **Compilation** : compiler soi-meme (CMake, Visual Studio, g++).
5. **Erreurs** : coller la sortie du compilateur dans l'onglet
   « Erreurs de compilation », cliquer sur
   « Analyser et demander la correction ». Les erreurs sont parsees et
   reinjectees avec les extraits de code concernes.

## Onglets

| Onglet | Role |
|---|---|
| Developpement | conversation, envoi du prompt, flux de reponse, resume manuel |
| Erreurs de compilation | collage de la sortie compilateur, parsing MSVC/GCC/Clang/CMake/linker, relance de correction |
| Fichiers | arborescence du projet, historique des ecritures de l'IA, restauration d'une sauvegarde, journal git, annulation du dernier commit |
| Savoirs | packs de connaissances, activation par projet, indexation, test de recherche |
| Parametres | modeles, temperature, budget de contexte, securite d'ecriture, git |

## Garde-fous d'ecriture

- aucun chemin absolu, aucune remontee `..` : tout est confine sous la racine
  du projet ;
- liste blanche d'extensions et de noms de fichiers (modifiable dans les
  parametres) ;
- sauvegarde horodatee de l'ancienne version dans `.ia_cpp/backups/` avant
  tout ecrasement ;
- revue de diff obligatoire par defaut ;
- un commit git par application, donc retour arriere immediat.

## Base de savoirs

Les fichiers `.md` et `.txt` du dossier `knowledge/` sont decoupes par
titres, vectorises via le modele d'embedding, puis stockes dans SQLite.
A chaque requete, les extraits les plus proches de la demande sont injectes
dans le contexte — bien plus efficace que de tenter d'envoyer « toutes les
regles du C++ » dans le prompt.

Packs fournis :

- `cpp_01_langage` : regles du langage (ODR, durees de vie, regle des cinq,
  heritage, templates, exceptions, comportements indefinis)
- `cpp_02_bibliotheque_standard` : choix de conteneurs, invalidation
  d'iterateurs, pointeurs intelligents, algorithmes, chaines, chrono,
  concurrence, pieges d'API
- `cpp_03_bonnes_pratiques` : interfaces, classes, nommage, performance,
  organisation de projet, options de compilation
- `cpp_04_pieges_frequents` : messages de compilation et leur cause reelle,
  pieges d'execution, specificites MSVC et embarque
- `cpp_05_cmake_build` : CMake par cible, commandes de build, erreurs
  frequentes

Pour ajouter un savoir : deposer un `.md` dans `knowledge/` (ou utiliser
« Ajouter un document... »), puis « Indexer le dossier knowledge/ ».
Chaque pack s'active ou se desactive par projet.

## Protocole d'echange de fichiers

Le modele est contraint par un protocole balise, plus robuste que du JSON
pour un petit modele local :

    ===FILE: src/main.cpp ACTION: create===
    contenu complet du fichier
    ===END===

`ACTION` vaut `create`, `replace` ou `delete`. Le contenu doit toujours etre
le fichier entier. Les blocs de code annotes
(` ```cpp file="src/main.cpp" `) sont acceptes en repli.

## Contexte envoye au modele

1. prompt systeme (`prompts/system_code.md`, editable a chaud) + protocole
   + fiche projet ;
2. extraits pertinents de la base de savoirs ;
3. manifeste du projet : arborescence et declarations principales des
   fichiers existants ;
4. resume glissant des echanges anciens, produit par le modele leger ;
5. N derniers messages bruts ;
6. erreurs de compilation en attente, avec extraits de code ;
7. prompt courant.

Le budget en tokens est configurable ; au-dela, l'historique ancien est
resume automatiquement.

## Arborescence

    ia_cpp/
      main.py                 point d'entree (--check, --index)
      lancer.bat              lanceur Windows
      core/
        config.py             configuration portable (JSON)
        db.py                 SQLite + migrations
        ollama_client.py      client HTTP (streaming, embeddings)
        protocol.py           parsing des blocs ===FILE:===
        files.py              ecriture confinee, sauvegardes, diff, manifeste
        gitrepo.py            depot git du projet
        rag.py                decoupage, embeddings, recherche cosinus
        errors.py             parsing des sorties de compilateur
        context.py            budget de contexte, resume glissant
        engine.py             orchestration (testable sans interface)
      ui/
        app.py                fenetre principale
        dialogs.py            fiche projet, revue de diff
      prompts/                prompts systeme editables
      knowledge/              packs de savoirs (markdown)
      data/                   base SQLite, config, journaux (cree au 1er lancement)

Les donnees peuvent etre deplacees via la variable d'environnement
`IA_CPP_HOME`.

## Journaux

Chaque echange est journalise dans `data/logs/AAAA-MM-JJ.jsonl` : contexte
complet envoye, reponse brute, fichiers touches, duree. Utile pour deboguer
un comportement du modele ou constituer plus tard un jeu de donnees.

## Limites connues

- Un modele a 2 milliards de parametres (`gemma4:e2b`) produit rarement du
  C++ multi-fichiers qui compile du premier coup. Il convient aux resumes et
  aux titres ; pour le code, un modele specialise de 7B ou plus est
  nettement plus fiable. Les deux sont configurables separement.
- Le modele ne compile pas et n'execute rien : la boucle passe par vous.
- Pas d'analyse statique automatique du code genere (clang-format,
  cppcheck) : prevu pour une version ulterieure.
