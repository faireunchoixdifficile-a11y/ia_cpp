"""Boites de dialogue : fiche projet et revue de diff avant ecriture."""
from __future__ import annotations

import tkinter as tk
from pathlib import Path
from tkinter import filedialog, messagebox, ttk

from core import files as fs

CPP_STANDARDS = ["c++11", "c++14", "c++17", "c++20", "c++23"]
COMPILERS = ["MSVC", "GCC", "Clang", "MinGW-w64"]
PLATFORMS = ["Windows", "Linux", "macOS", "Embarque / bare-metal"]
BUILD_SYSTEMS = ["CMake", "Visual Studio", "Makefile", "Aucun (compilation manuelle)"]


class ProjectDialog(tk.Toplevel):
    """Creation / edition d'un projet."""

    def __init__(self, master, title: str = "Nouveau projet", project=None) -> None:
        super().__init__(master)
        self.title(title)
        self.transient(master)
        self.resizable(True, False)
        self.result: dict | None = None

        self.var_name = tk.StringVar(value=project["name"] if project else "")
        self.var_path = tk.StringVar(value=project["path"] if project else "")
        self.var_std = tk.StringVar(value=project["cpp_standard"] if project else "c++20")
        self.var_compiler = tk.StringVar(value=project["compiler"] if project else "MSVC")
        self.var_platform = tk.StringVar(value=project["platform"] if project else "Windows")
        self.var_build = tk.StringVar(value=project["build_system"] if project else "CMake")

        frame = ttk.Frame(self, padding=12)
        frame.pack(fill="both", expand=True)
        frame.columnconfigure(1, weight=1)

        row = 0
        ttk.Label(frame, text="Nom du projet").grid(row=row, column=0, sticky="w", pady=4)
        ttk.Entry(frame, textvariable=self.var_name).grid(row=row, column=1, columnspan=2,
                                                          sticky="ew", pady=4)
        row += 1
        ttk.Label(frame, text="Dossier projet").grid(row=row, column=0, sticky="w", pady=4)
        ttk.Entry(frame, textvariable=self.var_path).grid(row=row, column=1, sticky="ew", pady=4)
        ttk.Button(frame, text="Parcourir...", command=self._browse).grid(row=row, column=2,
                                                                         padx=(6, 0), pady=4)
        row += 1
        ttk.Label(frame, text="Standard C++").grid(row=row, column=0, sticky="w", pady=4)
        ttk.Combobox(frame, textvariable=self.var_std, values=CPP_STANDARDS,
                     state="readonly").grid(row=row, column=1, columnspan=2, sticky="ew", pady=4)
        row += 1
        ttk.Label(frame, text="Compilateur").grid(row=row, column=0, sticky="w", pady=4)
        ttk.Combobox(frame, textvariable=self.var_compiler, values=COMPILERS,
                     state="readonly").grid(row=row, column=1, columnspan=2, sticky="ew", pady=4)
        row += 1
        ttk.Label(frame, text="Plateforme").grid(row=row, column=0, sticky="w", pady=4)
        ttk.Combobox(frame, textvariable=self.var_platform, values=PLATFORMS,
                     state="readonly").grid(row=row, column=1, columnspan=2, sticky="ew", pady=4)
        row += 1
        ttk.Label(frame, text="Build").grid(row=row, column=0, sticky="w", pady=4)
        ttk.Combobox(frame, textvariable=self.var_build, values=BUILD_SYSTEMS,
                     state="readonly").grid(row=row, column=1, columnspan=2, sticky="ew", pady=4)
        row += 1
        ttk.Label(frame, text="Conventions de code").grid(row=row, column=0, sticky="nw", pady=4)
        self.txt_style = tk.Text(frame, height=3, wrap="word")
        self.txt_style.grid(row=row, column=1, columnspan=2, sticky="ew", pady=4)
        if project:
            self.txt_style.insert("1.0", project["style_notes"] or "")
        row += 1
        ttk.Label(frame, text="Consignes projet\n(prompt systeme)").grid(row=row, column=0,
                                                                        sticky="nw", pady=4)
        self.txt_prompt = tk.Text(frame, height=5, wrap="word")
        self.txt_prompt.grid(row=row, column=1, columnspan=2, sticky="ew", pady=4)
        if project:
            self.txt_prompt.insert("1.0", project["system_prompt"] or "")
        row += 1

        buttons = ttk.Frame(frame)
        buttons.grid(row=row, column=0, columnspan=3, sticky="e", pady=(12, 0))
        ttk.Button(buttons, text="Annuler", command=self.destroy).pack(side="right", padx=4)
        ttk.Button(buttons, text="Valider", command=self._validate).pack(side="right")

        self.bind("<Escape>", lambda _e: self.destroy())
        self.grab_set()
        self.update_idletasks()
        self.minsize(560, self.winfo_reqheight())

    def _browse(self) -> None:
        initial = self.var_path.get() or str(Path.home())
        chosen = filedialog.askdirectory(parent=self, title="Dossier du projet C++",
                                         initialdir=initial)
        if chosen:
            self.var_path.set(chosen)
            if not self.var_name.get().strip():
                self.var_name.set(Path(chosen).name)

    def _validate(self) -> None:
        name = self.var_name.get().strip()
        path = self.var_path.get().strip()
        if not name:
            messagebox.showwarning("Projet", "Le nom est obligatoire.", parent=self)
            return
        if not path:
            messagebox.showwarning("Projet", "Le dossier projet est obligatoire.", parent=self)
            return
        folder = Path(path)
        if not folder.exists():
            if not messagebox.askyesno("Projet",
                                       f"Le dossier n'existe pas :\n{folder}\n\nLe creer ?",
                                       parent=self):
                return
            try:
                folder.mkdir(parents=True, exist_ok=True)
            except OSError as exc:
                messagebox.showerror("Projet", f"Creation impossible : {exc}", parent=self)
                return
        self.result = {
            "name": name,
            "path": str(folder),
            "cpp_standard": self.var_std.get(),
            "compiler": self.var_compiler.get(),
            "platform": self.var_platform.get(),
            "build_system": self.var_build.get(),
            "style_notes": self.txt_style.get("1.0", "end").strip(),
            "system_prompt": self.txt_prompt.get("1.0", "end").strip(),
        }
        self.destroy()


class DiffDialog(tk.Toplevel):
    """Revue des modifications proposees avant ecriture sur le disque."""

    MARK_ON = "[x]"
    MARK_OFF = "[ ]"

    def __init__(self, master, root_path: str, ops, font_mono: str = "Consolas",
                 font_size: int = 10) -> None:
        super().__init__(master)
        self.title("Revue des modifications proposees")
        self.transient(master)
        self.root_path = Path(root_path)
        self.ops = list(ops)
        self.selected: dict[str, bool] = {op.path: True for op in self.ops}
        self.accepted: list = []

        container = ttk.Frame(self, padding=8)
        container.pack(fill="both", expand=True)
        container.rowconfigure(1, weight=1)
        container.columnconfigure(0, weight=1)

        self.lbl_header = ttk.Label(
            container,
            text=(f"{len(self.ops)} fichier(s) proposes dans {self.root_path}. "
                  "Clique sur la colonne de gauche (ou barre d'espace) pour inclure/exclure."),
        )
        self.lbl_header.grid(row=0, column=0, sticky="w", pady=(0, 6))

        panes = ttk.Panedwindow(container, orient="horizontal")
        panes.grid(row=1, column=0, sticky="nsew")

        left = ttk.Frame(panes)
        self.tree = ttk.Treeview(left, columns=("sel", "path", "action", "delta"),
                                 show="headings", selectmode="browse", height=14)
        self.tree.heading("sel", text="")
        self.tree.heading("path", text="Fichier")
        self.tree.heading("action", text="Action")
        self.tree.heading("delta", text="+/-")
        self.tree.column("sel", width=36, anchor="center", stretch=False)
        self.tree.column("path", width=330, anchor="w")
        self.tree.column("action", width=92, anchor="center", stretch=False)
        self.tree.column("delta", width=84, anchor="center", stretch=False)
        scroll = ttk.Scrollbar(left, orient="vertical", command=self.tree.yview)
        self.tree.configure(yscrollcommand=scroll.set)
        self.tree.pack(side="left", fill="both", expand=True)
        scroll.pack(side="right", fill="y")
        panes.add(left, weight=1)

        right = ttk.Frame(panes)
        self.text = tk.Text(right, wrap="none", font=(font_mono, font_size),
                            background="#f7f7f7", height=22)
        yscroll = ttk.Scrollbar(right, orient="vertical", command=self.text.yview)
        xscroll = ttk.Scrollbar(right, orient="horizontal", command=self.text.xview)
        self.text.configure(yscrollcommand=yscroll.set, xscrollcommand=xscroll.set)
        self.text.grid(row=0, column=0, sticky="nsew")
        yscroll.grid(row=0, column=1, sticky="ns")
        xscroll.grid(row=1, column=0, sticky="ew")
        right.rowconfigure(0, weight=1)
        right.columnconfigure(0, weight=1)
        self.text.tag_configure("add", foreground="#0a6b2d")
        self.text.tag_configure("del", foreground="#a3141b")
        self.text.tag_configure("hunk", foreground="#1b4f9c")
        self.text.tag_configure("warn", foreground="#8a5a00")
        panes.add(right, weight=3)

        buttons = ttk.Frame(container)
        buttons.grid(row=2, column=0, sticky="ew", pady=(8, 0))
        ttk.Button(buttons, text="Tout cocher", command=lambda: self._set_all(True)).pack(side="left")
        ttk.Button(buttons, text="Tout decocher",
                   command=lambda: self._set_all(False)).pack(side="left", padx=4)
        ttk.Button(buttons, text="Annuler (ne rien ecrire)",
                   command=self._cancel).pack(side="right")
        ttk.Button(buttons, text="Appliquer la selection",
                   command=self._apply).pack(side="right", padx=6)

        self._fill()
        self.tree.bind("<<TreeviewSelect>>", lambda _e: self._show_selected())
        self.tree.bind("<Button-1>", self._on_click)
        self.tree.bind("<space>", lambda _e: self._toggle_current())
        self.bind("<Escape>", lambda _e: self._cancel())
        self.protocol("WM_DELETE_WINDOW", self._cancel)

        self.grab_set()
        self.update_idletasks()
        width = min(1180, max(900, self.winfo_screenwidth() - 160))
        height = min(760, max(560, self.winfo_screenheight() - 200))
        self.geometry(f"{width}x{height}")
        if self.ops:
            first = self.tree.get_children()[0]
            self.tree.selection_set(first)
            self.tree.focus(first)

    # --------------------------------------------------------------- interne
    def _fill(self) -> None:
        self.tree.tag_configure("suspect", foreground="#a3141b")
        suspects = 0
        for op in self.ops:
            added, removed = fs.diff_stats(self.root_path, op.path, op.content, op.action)
            label = ("! " + op.path) if op.warnings else op.path
            tags = ("suspect",) if op.warnings else ()
            if op.warnings:
                suspects += 1
            self.tree.insert("", "end", iid=op.path, tags=tags,
                             values=(self.MARK_ON, label, op.action, f"+{added}/-{removed}"))
        if suspects:
            self.lbl_header.configure(
                text=f"{len(self.ops)} fichier(s) proposes, dont {suspects} signale(s) en rouge : "
                     "lis l'avertissement en haut du diff avant d'appliquer.")

    def _op_for(self, path: str):
        for op in self.ops:
            if op.path == path:
                return op
        return None

    def _show_selected(self) -> None:
        selection = self.tree.selection()
        if not selection:
            return
        op = self._op_for(selection[0])
        if op is None:
            return
        diff = fs.preview_diff(self.root_path, op.path, op.content, op.action)
        self.text.configure(state="normal")
        self.text.delete("1.0", "end")
        if op.warnings:
            for warning in op.warnings:
                self.text.insert("end", f"! {warning}\n", "warn")
            self.text.insert("end", "\n")
        for line in diff.splitlines(keepends=True):
            if line.startswith("+++") or line.startswith("---"):
                self.text.insert("end", line, "hunk")
            elif line.startswith("@@"):
                self.text.insert("end", line, "hunk")
            elif line.startswith("+"):
                self.text.insert("end", line, "add")
            elif line.startswith("-"):
                self.text.insert("end", line, "del")
            else:
                self.text.insert("end", line)
        self.text.configure(state="disabled")

    def _on_click(self, event) -> None:
        if self.tree.identify_region(event.x, event.y) != "cell":
            return
        if self.tree.identify_column(event.x) != "#1":
            return
        item = self.tree.identify_row(event.y)
        if item:
            self._toggle(item)

    def _toggle_current(self) -> None:
        selection = self.tree.selection()
        if selection:
            self._toggle(selection[0])

    def _toggle(self, item: str) -> None:
        state = not self.selected.get(item, True)
        self.selected[item] = state
        values = list(self.tree.item(item, "values"))
        values[0] = self.MARK_ON if state else self.MARK_OFF
        self.tree.item(item, values=values)

    def _set_all(self, state: bool) -> None:
        for item in self.tree.get_children():
            self.selected[item] = state
            values = list(self.tree.item(item, "values"))
            values[0] = self.MARK_ON if state else self.MARK_OFF
            self.tree.item(item, values=values)

    def _apply(self) -> None:
        self.accepted = [op for op in self.ops if self.selected.get(op.path, False)]
        self.destroy()

    def _cancel(self) -> None:
        self.accepted = []
        self.destroy()
