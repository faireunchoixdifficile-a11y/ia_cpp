# CMake et chaine de compilation

Reference minimale pour produire un projet compilable par l'utilisateur.

## Squelette de CMakeLists.txt

    cmake_minimum_required(VERSION 3.20)
    project(MonProjet LANGUAGES CXX VERSION 0.1.0)

    set(CMAKE_CXX_STANDARD 20)
    set(CMAKE_CXX_STANDARD_REQUIRED ON)
    set(CMAKE_CXX_EXTENSIONS OFF)

    add_executable(mon_projet
        src/main.cpp
        src/module.cpp
    )

    target_include_directories(mon_projet PRIVATE src include)

    if (MSVC)
        target_compile_options(mon_projet PRIVATE /W4 /permissive- /EHsc)
    else()
        target_compile_options(mon_projet PRIVATE -Wall -Wextra -Wpedantic)
    endif()

Regle d'or : raisonner par cible (`target_*`) et non par variables globales.
Ne pas utiliser `include_directories` ni `add_definitions`.

## Bibliotheque plus executable

    add_library(coeur STATIC src/moteur.cpp src/calcul.cpp)
    target_include_directories(coeur PUBLIC include)
    target_compile_features(coeur PUBLIC cxx_std_20)

    add_executable(appli src/main.cpp)
    target_link_libraries(appli PRIVATE coeur)

`PUBLIC` propage aux consommateurs, `PRIVATE` reste interne, `INTERFACE` ne
s'applique qu'aux consommateurs.

## Ajouter un fichier source

Tout nouveau .cpp doit etre ajoute a la liste de sa cible, sinon erreur de
lien a l'utilisation. Les en-tetes n'ont pas besoin d'y figurer, mais les
lister ameliore l'affichage dans les IDE.

Eviter `file(GLOB ...)` pour collecter les sources : CMake ne detecte pas
l'ajout d'un fichier sans reconfiguration.

## Tests

    enable_testing()
    add_executable(tests tests/test_calcul.cpp)
    target_link_libraries(tests PRIVATE coeur)
    add_test(NAME calcul COMMAND tests)

## Dependances

    find_package(Threads REQUIRED)
    target_link_libraries(appli PRIVATE Threads::Threads)

Pour une dependance recuperee a la configuration :

    include(FetchContent)
    FetchContent_Declare(fmt
        GIT_REPOSITORY https://github.com/fmtlib/fmt.git
        GIT_TAG 10.2.1)
    FetchContent_MakeAvailable(fmt)
    target_link_libraries(appli PRIVATE fmt::fmt)

Toute dependance ajoutee doit etre signalee a l'utilisateur, car elle impose
un telechargement ou une installation.

## Commandes de build

Configuration et compilation hors source :

    cmake -S . -B build
    cmake --build build --config Debug -j

Avec un generateur precis :

    cmake -S . -B build -G "Visual Studio 17 2022" -A x64
    cmake -S . -B build -G Ninja -DCMAKE_BUILD_TYPE=Release

Types de build mono-configuration (Ninja, Makefiles) :
`-DCMAKE_BUILD_TYPE=Debug|Release|RelWithDebInfo`.
Les generateurs multi-configuration (Visual Studio) utilisent `--config`.

Nettoyage : supprimer le dossier `build`, pas de cible `clean` fiable.

## Compilation directe sans CMake

GCC / Clang :

    g++ -std=c++20 -Wall -Wextra -g -Isrc src/*.cpp -o appli

MSVC, depuis une invite "x64 Native Tools" :

    cl /std:c++20 /W4 /EHsc /Isrc src\*.cpp /Fe:appli.exe

## Base de compilation pour les outils

    set(CMAKE_EXPORT_COMPILE_COMMANDS ON)

Produit `build/compile_commands.json`, utilise par clang-tidy, clangd et les
editeurs. Copier ou lier ce fichier a la racine du projet.

## Erreurs CMake frequentes

`Cannot find source file` : chemin relatif errone, ou fichier pas encore cree.

`No CMAKE_CXX_COMPILER could be found` : environnement de compilation non
charge (sous Windows, lancer depuis l'invite des outils natifs) ou outils de
build absents.

`target ... links to itself` ou dependance circulaire : revoir le decoupage
en bibliotheques.

Modification de CMakeLists sans reconfiguration : relancer
`cmake -S . -B build`.

Melange de configurations Debug et Release dans un meme lien sous MSVC :
erreurs de symboles de runtime. Garder une configuration homogene.
