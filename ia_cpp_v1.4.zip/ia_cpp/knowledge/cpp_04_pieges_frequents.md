# Pieges frequents et messages de compilation

Catalogue des erreurs que le modele doit savoir eviter et diagnostiquer.

## Erreurs de compilation courantes et leur cause reelle

`undefined reference to ...` / `LNK2019 symbole externe non resolu`
Une declaration existe mais la definition manque a la liaison. Causes :
fichier .cpp absent de la cible du build, methode declaree et jamais definie,
fonction template definie dans un .cpp, mauvais ordre ou absence de
bibliotheque dans la ligne de lien.

`multiple definition of ...` / `LNK2005 deja defini`
Une definition se trouve dans un en-tete inclus plusieurs fois. Rendre la
fonction `inline`, ou deplacer la definition dans un seul .cpp. Pour une
variable, `inline constexpr` ou `extern` plus une definition unique.

`incomplete type` / `C2027 utilisation du type non defini`
On a declare la classe (`class Foo;`) sans l'inclure, et on utilise sa taille
ou ses membres. Une declaration anticipee suffit pour un pointeur ou une
reference, pas pour un membre par valeur ni pour un appel de methode.

`no matching function for call to ...`
Signature differente de ce qui est declare : const manquant, ordre des
parametres, conversion impossible, surcharge masquee par une methode de meme
nom dans une classe derivee (ajouter `using Base::methode;`).

`expected ';' before ...` sur une ligne qui parait correcte
L'erreur est generalement a la ligne precedente, ou dans un en-tete inclus,
ou provient d'une macro. Regarder au-dessus du point signale.

`C2065 identificateur non declare`
En-tete oublie, faute de frappe, ou nom dans un autre espace de noms.

`template argument deduction failed`
Les types deduits ne correspondent pas ; souvent un melange
`const`/non-const, ou un `std::vector<int>` passe a un parametre
`std::vector<T>&` non const depuis un temporaire.

`invalid initialization of non-const reference from rvalue`
On passe un temporaire a un parametre `T&`. Changer en `const T&` ou `T&&`.

`C1083 / fatal error: fichier include introuvable`
Chemin d'inclusion absent du build. Ajouter le repertoire avec
`target_include_directories`, ou corriger le chemin relatif.

`error: 'X' was not declared in this scope` dans un template
Nom dependant non qualifie : prefixer par `this->` pour un membre herite dans
une classe template.

## Pieges d'execution

Lecture hors bornes avec `operator[]`. Aucun diagnostic en release : utiliser
`at()` en developpement, ou compiler avec les sanitizers.

Iterateur invalide apres `push_back` : conserver un index plutot qu'un
iterateur si le conteneur grossit pendant le parcours.

Reference pendante sur un temporaire :

    const std::string& mauvais = fabriquer().nom();   // temporaire detruit

Lier a une valeur (`auto bon = fabriquer().nom();`) ou prolonger la duree de
vie de l'objet complet.

`std::string_view` construit sur un `std::string` temporaire : meme probleme,
plus silencieux encore.

Capture de lambda par reference stockee dans un `std::function` qui survit au
bloc : capturer par copie.

Division entiere involontaire : `1 / 2` vaut 0. Ecrire `1.0 / 2`.

Comparaison de flottants avec `==` : comparer a une tolerance.

Debordement signe lors d'un calcul intermediaire : promouvoir en type plus
large avant la multiplication.

`std::vector` passe par valeur dans une boucle : copie complete a chaque
appel, invisible dans le profil fonctionnel mais devastatrice en performance.

Ordre d'initialisation des membres different de l'ordre de la liste
d'initialisation : le compilateur suit l'ordre de declaration. Un membre
initialise a partir d'un autre declare apres lui lit une valeur indeterminee.

Appel de methode virtuelle dans un constructeur : la version de la classe en
cours de construction est appelee, pas celle de la derivee.

Oubli de `virtual` sur le destructeur d'une base polymorphique : fuite ou
destruction partielle.

Shadowing d'un membre par un parametre de meme nom : activer `-Wshadow`.

Course de donnees sur une variable partagee non atomique : le programme
semble fonctionner puis echoue sous charge.

Interblocage par verrouillage de deux mutex dans des ordres differents :
utiliser `std::scoped_lock` avec les deux mutex.

## Pieges specifiques Windows / MSVC

`min` et `max` definis en macros par `windows.h` : definir
`NOMINMAX` avant l'inclusion, ou entourer les appels de parentheses :
`(std::min)(a, b)`.

Conflit entre `TCHAR`, `wchar_t` et `char` : fixer explicitement les versions
A ou W des API (`CreateFileW`) plutot que de dependre de `UNICODE`.

Fins de ligne : un fichier ouvert en mode texte traduit `\n` en `\r\n`.
Ouvrir en `std::ios::binary` pour un format precis.

`__declspec(dllexport)` / `dllimport` : une bibliotheque dynamique exige une
macro d'export conditionnelle ; sans elle, LNK2019 cote consommateur.

Incoherence de runtime (/MT contre /MD) entre projet et bibliotheque : erreurs
de lien incomprehensibles. Aligner les options.

## Pieges specifiques embarque / temps reel

Pas d'allocation dynamique dans les sections critiques : preallouer, ou
utiliser des tampons statiques et des conteneurs a capacite fixe.

Les exceptions et le RTTI sont souvent desactives : prevoir une gestion
d'erreur par code de retour ou par type Result.

`volatile` ne remplace pas `std::atomic` : il sert aux registres materiels,
pas a la synchronisation entre threads.

Alignement et acces non alignes : utiliser `std::memcpy` pour recomposer un
entier depuis un tampon d'octets, jamais un cast de pointeur.

Boutisme : ne jamais serialiser une structure par copie memoire brute pour un
echange entre machines ; serialiser champ par champ.

Taille des types non garantie : employer `<cstdint>` (`std::uint32_t`), pas
`int` ni `long`.

## Diagnostic methodique quand ca ne compile pas

1. Lire la PREMIERE erreur, pas la derniere : les suivantes en decoulent.
2. Identifier le fichier et la ligne reels, en remontant la pile d'inclusion
   affichee par le compilateur.
3. Isoler : commenter la portion suspecte, ou reproduire dans un fichier de
   dix lignes.
4. Verifier les trois suspects habituels : en-tete manquant, signature
   divergente, definition absente du build.
5. Si l'erreur mentionne un template, lire la ligne d'instanciation, pas la
   ligne de definition.

## Conversions explicites refusees : le piege string_view vers string

Message MSVC typique, en cascade :

    'std::vector<std::string>::push_back' : aucune fonction surchargee
    n'a pu convertir tous les types d'arguments
    l'initialisation de copie de liste ne peut pas utiliser un
    constructeur marque 'explicit'

Cause : on pousse un `std::string_view` dans un `std::vector<std::string>`.
Le constructeur `std::string(std::string_view)` est **explicite**, donc
aucune conversion implicite n'a lieu. Le meme refus se produit pour tout
type dont le constructeur utile est marque `explicit`.

Corrections, par ordre de preference :

    champs.emplace_back(vue);                  // construit en place
    champs.push_back(std::string(vue));        // conversion explicite
    champs.push_back(std::string(vue.data(), vue.size()));  // si non terminee par 0

Le meme probleme apparait a l'appel d'une fonction :

    void analyze(const std::vector<std::string>& colonnes);
    analyze({vue1, vue2});   // refuse : liste d'initialisation non convertible
    analyze(std::vector<std::string>{std::string(vue1), std::string(vue2)});  // OK

Regle generale : quand un decoupeur de chaines produit des `string_view`,
decider une fois pour toutes si la structure resultat possede ses donnees
(`std::vector<std::string>`) ou les reference (`std::vector<std::string_view>`).
Melanger les deux produit soit cette erreur de compilation, soit, plus grave,
des vues pendantes quand la chaine source disparait.

Pour un parseur de fichier lu ligne par ligne, la ligne source est detruite a
l'iteration suivante : les champs doivent donc etre possedes, pas references.
