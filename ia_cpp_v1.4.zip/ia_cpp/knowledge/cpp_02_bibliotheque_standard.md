# Bibliotheque standard : choix corrects et signatures sures

Aide-memoire des composants a privilegier et des erreurs d'API frequentes.

## Choisir un conteneur

- `std::vector<T>` : choix par defaut. Contigu, cache-friendly, ajout en fin
  amorti constant. Reserver avec `reserve()` quand la taille est connue.
- `std::array<T, N>` : taille fixe connue a la compilation, pas d'allocation.
- `std::deque<T>` : insertion aux deux extremites, pas de contiguite garantie.
- `std::list<T>` : uniquement si l'on a besoin de stabilite des iterateurs et
  d'epissage. Rarement le bon choix en pratique.
- `std::map` / `std::set` : ordonne, arbre equilibre, O(log n), iterateurs
  stables. `std::unordered_map` / `unordered_set` : table de hachage, O(1)
  amorti, pas d'ordre, iterateurs invalides au rehash.
- `std::string` pour du texte possede, `std::string_view` pour une vue non
  possedante en lecture seule. Ne jamais conserver un `string_view` sur un
  temporaire detruit.
- `std::span<T>` (C++20) : vue non possedante sur une sequence contigue,
  remplace le couple pointeur + taille.

## Invalidation des iterateurs

- `vector` : toute reallocation (ajout depassant la capacite) invalide tout ;
  une insertion ou suppression invalide a partir du point de modification.
- `deque` : insertion au milieu invalide tout ; aux extremites, invalide les
  iterateurs mais pas les references.
- `map`, `set`, `list` : seules les suppressions invalident, et uniquement
  l'element supprime.
- `unordered_*` : le rehash invalide les iterateurs, pas les references.

Supprimer en parcourant se fait avec le resultat de `erase` :

    for (auto it = v.begin(); it != v.end(); ) {
        if (doit_supprimer(*it)) it = v.erase(it);
        else ++it;
    }

Ou, plus simplement, `std::erase_if(v, predicat)` en C++20.

## Acces aux elements

`operator[]` sur un `vector` hors bornes est un comportement indefini ;
`at()` leve `std::out_of_range`. Sur une `map`, `operator[]` cree l'element
absent avec une valeur par defaut, ce qui est une source classique de bug en
lecture : utiliser `find()` ou `contains()` (C++20).

`front()` et `back()` sur un conteneur vide sont un comportement indefini :
tester `empty()` d'abord.

## Pointeurs intelligents

- `std::unique_ptr<T>` : propriete exclusive, cout nul. Construire avec
  `std::make_unique<T>(args...)`. Pour un tableau : `std::unique_ptr<T[]>`.
- `std::shared_ptr<T>` : propriete partagee, compteur atomique. Construire
  avec `std::make_shared<T>(args...)`. Ne pas en abuser : un `shared_ptr`
  signale une propriete reellement partagee, pas une commodite.
- `std::weak_ptr<T>` : rompt les cycles de references ; verrouiller avec
  `lock()` qui rend un `shared_ptr` eventuellement nul.
- Ne jamais construire deux pointeurs intelligents distincts depuis le meme
  pointeur brut : double liberation.
- Passer un `unique_ptr` par valeur transfere la propriete ; le passer par
  `const&` n'a pratiquement jamais de sens.

## Algorithmes

Entete `<algorithm>` et `<numeric>`. Preferer un algorithme nomme a une
boucle ecrite a la main.

Classiques : `std::find`, `std::find_if`, `std::count_if`, `std::sort`,
`std::stable_sort`, `std::lower_bound` (sur plage triee), `std::transform`,
`std::accumulate`, `std::reduce`, `std::all_of` / `any_of` / `none_of`,
`std::copy_if`, `std::unique` (a combiner avec `erase`), `std::rotate`,
`std::min_element` / `max_element`, `std::clamp`.

Le couple `remove` + `erase` est le motif historique :

    v.erase(std::remove(v.begin(), v.end(), valeur), v.end());

En C++20, `std::erase(v, valeur)` fait la meme chose.

`std::sort` exige un ordre strict faible : le comparateur doit renvoyer faux
pour deux elements egaux. Un comparateur `<=` provoque un comportement
indefini.

Les ranges de C++20 simplifient l'ecriture :
`std::ranges::sort(v)`, `std::ranges::find(v, x)`, et les vues composables
`std::views::filter`, `std::views::transform`, `std::views::take`.

## Chaines de caracteres

- Concatenation : `operator+`, ou `append`, ou `std::ostringstream` pour un
  assemblage repete.
- Conversion : `std::stoi`, `std::stod` (levent une exception),
  `std::from_chars` (sans allocation ni exception, a preferer en code chaud),
  `std::to_string`, `std::to_chars`.
- Formatage : `std::format` (C++20) est a preferer aux flux et a `printf`.
  `std::format("{} a {} ans", nom, age)`.
- Recherche : `find` renvoie `std::string::npos` en cas d'echec ; comparer a
  `npos` et non a -1.
- `c_str()` rend un pointeur valide tant que la chaine n'est pas modifiee.

## Entrees / sorties et fichiers

`<fstream>` : `std::ifstream`, `std::ofstream`. Tester l'ouverture avec
`is_open()` ou via la conversion booleenne du flux. Lire ligne a ligne avec
`std::getline(flux, ligne)`. Pour du binaire, ouvrir avec
`std::ios::binary` et utiliser `read` / `write`.

`<filesystem>` (C++17) : `std::filesystem::path`, `exists`, `create_directories`,
`directory_iterator`, `file_size`, `remove`. Les surcharges avec
`std::error_code` evitent les exceptions.

Ne jamais melanger `std::endl` et les boucles chaudes : `'\n'` suffit,
`std::endl` force un vidage du tampon.

## Temps

`<chrono>` : `std::chrono::steady_clock` pour mesurer une duree,
`system_clock` pour une date. Les durees sont typees :
`std::chrono::milliseconds`, conversion par `duration_cast`.

    auto debut = std::chrono::steady_clock::now();
    // ...
    auto ms = std::chrono::duration_cast<std::chrono::milliseconds>(
        std::chrono::steady_clock::now() - debut).count();

## Concurrence

`std::thread` doit etre `join()` ou `detach()` avant destruction, sinon
terminaison du programme. `std::jthread` (C++20) rejoint automatiquement.

Proteger toute donnee partagee mutable par un `std::mutex` et un verrou RAII.
Verrouiller plusieurs mutex avec `std::scoped_lock` pour eviter l'interblocage.

`std::atomic<T>` pour les compteurs et drapeaux simples.
`std::future` / `std::async` pour un resultat differe.
`std::condition_variable` s'attend toujours dans une boucle avec predicat.

## Types utilitaires

- `std::optional<T>` : valeur eventuellement absente. Tester avant `value()`,
  ou utiliser `value_or(defaut)`.
- `std::variant<A, B>` : union typee, visiter avec `std::visit`.
- `std::tuple` / `std::pair`, deballage par liaisons structurees :
  `auto [cle, valeur] = *it;`
- `std::expected<T, E>` (C++23) : resultat ou erreur, sans exception.
- `std::byte` pour un octet brut, plus clair que `char` ou `unsigned char`.

## Pieges d'API frequents

- `std::move` ne deplace rien : il produit une rvalue. L'objet source reste
  valide mais dans un etat non specifie ; ne plus en lire la valeur.
- Apres `std::forward`, ne plus utiliser le parametre.
- Capturer par reference dans une lambda stockee au-dela de la portee locale
  est une reference pendante : capturer par copie, ou capturer explicitement.
- `std::vector<bool>` n'est pas un conteneur de `bool` : utiliser
  `std::vector<char>` ou `std::bitset` si l'on a besoin de references reelles.
- `size()` rend un type non signe : eviter `for (int i = 0; i < v.size(); ++i)`
  qui declenche un avertissement de comparaison signe / non signe ;
  utiliser `std::size_t` ou une boucle sur intervalle.
- `std::getline` apres `operator>>` lit la fin de ligne restante : vider avec
  `std::ws` ou `ignore`.
