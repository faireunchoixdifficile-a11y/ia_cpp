# Bonnes pratiques et style de code C++

Synthese des principes largement admis dans la profession (esprit des
C++ Core Guidelines), reformulee pour servir de consigne de production.

## Philosophie

Exprimer l'intention dans le code plutot que dans un commentaire. Un nom
juste vaut mieux qu'une explication.

Rendre les erreurs impossibles a la compilation plutot que detectables a
l'execution : types forts, enumerations de classe, unites typees.

Ne pas payer pour ce qu'on n'utilise pas, mais ne pas optimiser avant de
mesurer. La lisibilite est la performance par defaut.

## Interfaces

Une fonction fait une chose et porte un nom qui le dit. Si le nom contient
"et", la decouper.

Preferer peu de parametres. Au-dela de quatre, regrouper dans une structure
nommee. Eviter deux parametres consecutifs de meme type facilement
permutables : introduire des types distincts.

Rendre les preconditions explicites : `assert` en interne, exception ou code
d'erreur a la frontiere publique.

Ne pas renvoyer de pointeur brut possedant. Signaler la propriete par le
type de retour : `std::unique_ptr<T>` pour transferer, `T&` pour un acces non
possedant garanti non nul, `T*` pour un acces optionnel.

Declarer `const` tout ce qui peut l'etre : parametres, methodes, variables
locales. Le compilateur devient un verificateur.

Utiliser `[[nodiscard]]` sur une fonction dont ignorer le retour est un bug.

## Enumerations

Toujours `enum class` et non `enum` nu : pas de conversion implicite vers
l'entier, pas de pollution de l'espace de noms.

    enum class State : std::uint8_t { Idle, Running, Stopped };

Un `switch` sur une enumeration couvre tous les cas ; eviter le `default`
pour que le compilateur signale un cas oublie lors d'un ajout.

## Classes

Rendre les donnees membres privees. Une structure sans invariant peut etre un
`struct` a membres publics, sans methode.

Un seul niveau d'abstraction par classe. Si une classe a plus de dix methodes
publiques, elle en fait probablement trop.

Initialiser tous les membres. Marquer `explicit` les constructeurs a un
argument. Definir `operator==` par defaut quand la comparaison membre a
membre convient (`bool operator==(const T&) const = default;` en C++20).

Preferer des fonctions libres aux methodes quand l'operation n'a pas besoin
de l'etat prive : cela reduit le couplage.

## Fonctions et boucles

Preferer la boucle sur intervalle :

    for (const auto& item : collection) { ... }

Prendre par `const auto&` pour eviter une copie silencieuse, par `auto&` pour
modifier, par `auto` seulement pour les types scalaires.

Limiter la portee des variables au bloc ou elles servent. Declarer au plus
pres de l'usage, avec initialisation.

Sortir tot des fonctions (garde en debut) plutot que d'imbriquer des `if`.

## Deplacement et performance

Retourner par valeur : l'elision de copie et le deplacement rendent cela
efficace. Ne jamais ecrire `return std::move(local);` sur une variable locale,
cela empeche l'elision.

Passer par valeur puis `std::move` dans le membre, pour un parametre qui sera
stocke :

    explicit Message(std::string text) : text_(std::move(text)) {}

Reserver la capacite des conteneurs quand la taille finale est connue.
Eviter les copies de `std::string` dans les boucles : `string_view` en
lecture, `reserve` plus `append` en ecriture.

Mesurer avant d'optimiser, avec un profileur et sur une version compilee en
mode optimise.

## Organisation d'un projet

    projet/
      CMakeLists.txt
      include/projet/      en-tetes publics
      src/                 sources et en-tetes internes
      tests/               tests unitaires
      third_party/         dependances vendorisees

Les en-tetes publics s'incluent par chemin prefixe :
`#include <projet/module.h>`, ce qui evite les collisions de noms.

Un module = un couple .h / .cpp coherent. Pas de fichier fourre-tout
"utils.cpp" qui grossit sans limite.

## Commentaires

Commenter le pourquoi, pas le quoi. Un commentaire qui paraphrase le code est
une dette : il deviendra faux.

Documenter en tete de fonction : but, preconditions, propriete des
parametres, exceptions possibles. Deux a quatre lignes suffisent.

Pas de code mort en commentaire : le gestionnaire de versions sert a cela.

## Nommage (convention proposee, a adapter au projet)

- types et classes : `PascalCase`
- fonctions et variables : `snake_case` ou `camelCase`, mais un seul style
  dans tout le projet
- membres prives : suffixe `_` (`count_`)
- constantes : `kMaxSize` ou `MAX_SIZE`, pas les deux
- macros : `MAJUSCULES_AVEC_UNDERSCORES`, et le moins possible de macros

Le nom dit l'intention et l'unite : `timeout_ms`, `buffer_size_bytes`,
`retry_count`. Pas d'abreviation obscure, pas de nom d'une lettre hors
compteur de boucle court.

## Tests

Tester les frontieres : zero, un, maximum, valeurs invalides. Un test par
comportement, nomme d'apres ce qu'il verifie.

Separer le code testable (logique pure) des effets de bord (fichiers,
reseau, materiel) : la logique se teste sans monter d'infrastructure.

Un bug corrige commence par un test qui echoue.

## Options de compilation recommandees

GCC / Clang :

    -std=c++20 -Wall -Wextra -Wpedantic -Wshadow -Wconversion
    -Wold-style-cast -Wnon-virtual-dtor
    debug :   -g -O0 -fsanitize=address,undefined
    release : -O2 -DNDEBUG

MSVC :

    /std:c++20 /W4 /permissive- /EHsc
    debug :   /Zi /Od /RTC1
    release : /O2 /DNDEBUG

Traiter les avertissements comme des erreurs des que la base de code est
propre (`-Werror`, `/WX`).

Outils complementaires : `clang-format` pour la mise en forme,
`clang-tidy` et `cppcheck` pour l'analyse statique, les sanitizers
(address, undefined, thread) pour l'execution.

## Ce qu'il faut eviter

- macros a la place de constantes, de fonctions inline ou de templates
- `using namespace std;` en portee globale, et jamais dans un en-tete
- tableaux C et arithmetique de pointeurs la ou un conteneur convient
- casts de type C `(T)x` : utiliser `static_cast`, `const_cast` (rarement),
  `reinterpret_cast` (exceptionnellement, et commente)
- variables globales mutables
- heritage pour reutiliser du code sans relation "est un"
- fonctions de plus d'une cinquantaine de lignes
- gestion d'erreur par code de retour ignore
