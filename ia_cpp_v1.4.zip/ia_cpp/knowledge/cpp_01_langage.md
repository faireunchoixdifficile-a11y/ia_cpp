# Regles du langage C++ : socle a respecter

Fiche de reference condensee, redigee pour servir de garde-fou au modele.
Standard de reference : C++17 / C++20.

## Unites de traduction, declaration, definition

Une declaration annonce l'existence d'un nom ; une definition en fournit le
corps ou l'emplacement memoire. Un nom doit etre declare avant d'etre utilise.

Regle de definition unique : chaque fonction non inline et chaque variable
non inline a exactement une definition dans tout le programme. Les classes,
les templates et les fonctions inline peuvent apparaitre dans plusieurs
unites de traduction a condition que la definition y soit identique.

Consequences pratiques :
- les definitions de fonctions libres vont dans un .cpp, pas dans un .h,
  sauf si elles sont `inline`, `constexpr` ou membres definis dans la classe ;
- une variable globale se declare `extern` dans l'en-tete et se definit dans
  un seul .cpp ; en C++17 on prefere `inline constexpr` dans l'en-tete ;
- une erreur de type LNK2005 ou "multiple definition" signale presque toujours
  une definition laissee dans un en-tete.

## Gardes d'en-tete

Tout en-tete commence par `#pragma once` (support universel en pratique) ou
par une garde nommee :

    #ifndef PROJET_MODULE_H
    #define PROJET_MODULE_H
    ...
    #endif

Un en-tete doit etre auto-suffisant : il inclut ce dont il a besoin et peut
etre inclus seul sans erreur.

## Duree de vie et portee

Un objet automatique vit jusqu'a la fin de son bloc. Retourner une reference
ou un pointeur vers un objet local est un comportement indefini.

L'ordre de destruction est l'inverse de l'ordre de construction dans un meme
bloc. Les membres d'une classe sont detruits dans l'ordre inverse de leur
declaration, apres le corps du destructeur.

Les objets statiques d'une meme unite de traduction sont initialises dans
l'ordre de declaration ; entre unites de traduction differentes, l'ordre
n'est pas specifie. Pour un singleton, preferer une variable statique locale
a une fonction, dont l'initialisation est garantie et thread-safe depuis C++11.

## const, constexpr, consteval

`const` interdit la modification via ce nom. `constexpr` indique qu'une
evaluation a la compilation est possible ; sur une fonction, cela n'oblige
pas l'evaluation a la compilation. `consteval` (C++20) l'impose.

`const` sur une methode signifie que la methode ne modifie pas l'etat
observable. Une methode `const` ne peut appeler que des methodes `const`.
`mutable` autorise la modification d'un membre depuis une methode `const`,
usage reserve aux caches et aux mutex.

Preferer `constexpr`/`inline constexpr` aux macros pour les constantes.

## References, pointeurs, valeurs

Une reference doit etre liee a la construction et ne peut pas etre reliee.
Elle ne peut pas etre nulle. Un pointeur peut etre nul et doit alors etre
teste avant dereferencement.

Conventions de passage d'arguments :
- type scalaire ou petit type copiable : par valeur ;
- objet volumineux en lecture seule : `const T&` ;
- objet a modifier : `T&` ;
- transfert de propriete : par valeur avec `std::move` cote appelant, ou
  `std::unique_ptr<T>` par valeur ;
- parametre optionnel sans propriete : pointeur brut `T*` ou
  `std::optional<std::reference_wrapper<T>>`.

## Semantique de valeur : regle des zero, trois, cinq

Si une classe gere une ressource brute, elle doit definir destructeur,
constructeur de copie, affectation de copie, constructeur de deplacement et
affectation de deplacement (les cinq). Le mieux reste de ne gerer aucune
ressource brute et de n'en declarer aucune (regle des zero), en s'appuyant
sur les conteneurs standard et les pointeurs intelligents.

Declarer l'une des cinq operations desactive ou deprecie la generation
automatique des autres : soit on n'en declare aucune, soit on les traite
toutes explicitement, `= default` ou `= delete` compris.

## Constructeurs

Initialiser les membres dans la liste d'initialisation, dans l'ordre de
declaration des membres, et non dans le corps du constructeur.

Un constructeur a un seul parametre doit etre `explicit`, sauf si la
conversion implicite est reellement souhaitee.

Depuis C++11, un membre peut recevoir un initialiseur par defaut a sa
declaration ; c'est la forme a preferer pour les valeurs constantes.

Ne jamais appeler une methode virtuelle depuis un constructeur ou un
destructeur : la resolution dynamique n'est pas encore, ou plus, celle de la
classe derivee.

## Heritage et polymorphisme

Une classe destinee a servir de base polymorphique doit avoir un destructeur
virtuel, sinon la destruction via un pointeur de base est un comportement
indefini.

Marquer `override` sur toute redefinition et `final` lorsque la redefinition
doit s'arreter. `override` fait echouer la compilation si la signature ne
correspond a aucune methode virtuelle de la base : c'est le filet le plus
rentable du langage.

Preferer la composition a l'heritage. Reserver l'heritage public a une
relation "est un" verifiee, avec substituabilite reelle.

Eviter le decoupage d'objet (object slicing) : ne jamais stocker des objets
derives dans un conteneur de la classe de base par valeur ; stocker des
`std::unique_ptr<Base>`.

## Surcharge, resolution, conversions

La resolution de surcharge choisit la meilleure correspondance exacte, puis
les promotions, puis les conversions standard, puis les conversions
definies par l'utilisateur. Une ambiguite est une erreur de compilation.

Les conversions numeriques implicites sont une source classique de bugs :
restreindre avec `static_cast` explicite, eviter le melange signe / non
signe, se mefier de la comparaison entre `int` et `size_t`.

## Templates

Un template est compile a l'instanciation : son code doit etre visible du
point d'instanciation. En pratique, definitions de templates dans l'en-tete
(ou dans un .ipp / .inl inclus en fin d'en-tete).

`typename` est requis pour un nom dependant designant un type :
`typename std::vector<T>::iterator`.

Depuis C++20, preferer les concepts aux astuces SFINAE :

    template <std::integral T>
    T doubler(T value) { return value * 2; }

## Espaces de noms

Encapsuler le code du projet dans un espace de noms. Jamais de
`using namespace` dans un en-tete. Dans un .cpp, limiter la portee d'un
`using` au bloc qui en a besoin.

Un espace de noms anonyme dans un .cpp donne une liaison interne aux
symboles : c'est la bonne facon de rendre une fonction locale au fichier.

## Exceptions et gestion d'erreur

Lancer par valeur, capturer par reference constante. Deriver ses exceptions
de `std::exception` ou de ses specialisations.

Un destructeur ne doit jamais laisser echapper une exception.

Marquer `noexcept` les fonctions qui ne peuvent pas lancer, en particulier
les operations de deplacement : les conteneurs standard choisissent des
strategies plus efficaces quand le deplacement est `noexcept`.

Alternative sans exception, utile en embarque : codes de retour,
`std::optional<T>`, `std::expected<T, E>` (C++23), ou un type Result maison.

## RAII

Toute ressource (memoire, fichier, socket, mutex, handle systeme) doit etre
detenue par un objet qui la libere dans son destructeur. Aucune liberation
manuelle dans le chemin d'erreur, aucun `goto cleanup`.

Verrouillage : `std::lock_guard`, `std::unique_lock`, `std::scoped_lock`
plutot que `mutex.lock()` / `mutex.unlock()`.

## Comportements indefinis a ne jamais produire

- dereferencement d'un pointeur nul, pendant ou non initialise ;
- acces hors bornes d'un tableau ou d'un `std::vector` via `operator[]` ;
- depassement signe d'un entier ;
- lecture d'une variable non initialisee ;
- violation de la regle de stricte correspondance de types (type punning via
  cast de pointeur ; utiliser `std::memcpy` ou `std::bit_cast` en C++20) ;
- utilisation d'un iterateur invalide apres modification du conteneur ;
- course de donnees entre threads sans synchronisation.

## Initialisation

Preferer l'initialisation par accolades `T x{...}` : elle interdit les
conversions avec perte. Attention au piege `std::vector<int> v{10}` qui cree
un vecteur d'un element valant 10, alors que `std::vector<int> v(10)` cree
dix elements nuls.

Toujours initialiser une variable a la declaration. Les membres scalaires
d'une classe doivent recevoir un initialiseur par defaut.
