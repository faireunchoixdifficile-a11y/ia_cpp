#!/usr/bin/env python3
"""Point d'entree de l'application IA C++ locale.

Usage :
    python main.py                 lance l'interface graphique
    python main.py --index         indexe les savoirs puis quitte (sans interface)
    python main.py --check         verifie la connexion a Ollama puis quitte
"""
from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

from core.config import Config, db_path, knowledge_dir  # noqa: E402
from core.db import Database  # noqa: E402


def resolve_model(wanted: str, installed: list[str]) -> str | None:
    """Retrouve un modele installe malgre l'etiquette implicite ':latest'.

    Ollama liste ses modeles avec leur etiquette complete ('nomic-embed-text:latest')
    alors qu'on les designe souvent sans ('nomic-embed-text'). Les deux formes
    pointent le meme modele : la comparaison doit donc etre normalisee.
    """
    if wanted in installed:
        return wanted
    base = wanted.split(":", 1)[0]
    candidates = [wanted, f"{base}:latest", base]
    for candidate in candidates:
        if candidate in installed:
            return candidate
    for name in installed:
        if name.split(":", 1)[0] == base:
            return name
    return None


def run_gui(config: Config, db: Database) -> int:
    try:
        import tkinter  # noqa: F401
    except ImportError:
        print("Tkinter est introuvable. Sous Windows, reinstalle Python en cochant tcl/tk.")
        return 2
    from ui.app import App

    app = App(config, db)
    app.mainloop()
    return 0


def run_index(config: Config, db: Database) -> int:
    from core.engine import Engine

    engine = Engine(config, db)
    results = engine.knowledge.ingest_directory(knowledge_dir(), progress=print)
    for result in results:
        print(f"  {result['pack']}: {result['status']} ({result['chunks']} extraits)")
    return 0


def run_check(config: Config) -> int:
    from core.ollama_client import OllamaClient, OllamaError

    client = OllamaClient(config["ollama_url"], 30)
    if not client.ping():
        print(f"Ollama injoignable sur {config['ollama_url']}")
        return 1
    try:
        models = client.list_models()
    except OllamaError as exc:
        print(f"Erreur : {exc}")
        return 1
    print(f"Ollama OK - {len(models)} modele(s) :")
    for name in models:
        print(f"  - {name}")
    missing = 0
    for key in ("model_code", "model_light", "model_embed"):
        wanted = str(config[key])
        resolved = resolve_model(wanted, models)
        if resolved is None:
            state = f"ABSENT (ollama pull {wanted})"
            missing += 1
        elif resolved != wanted:
            state = f"present (installe sous le nom {resolved})"
        else:
            state = "present"
        print(f"{key:12s} = {wanted:28s} {state}")
    if missing:
        print(f"\n{missing} modele(s) a installer.")
    return 0


def main(argv: list[str]) -> int:
    config = Config()
    if "--check" in argv:
        return run_check(config)
    db = Database(db_path())
    try:
        if "--index" in argv:
            return run_index(config, db)
        return run_gui(config, db)
    finally:
        db.close()


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
