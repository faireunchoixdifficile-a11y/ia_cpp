"""Construction du contexte envoye au modele + resume glissant.

Un petit modele local a un contexte etroit : on ne peut pas lui envoyer
"toutes les regles du C++" ni tout l'historique. La strategie est donc :

  system   = role + protocole fichiers + fiche projet + style
  bloc 1   = extraits pertinents de la base de savoirs (RAG)
  bloc 2   = manifeste du projet (arborescence + declarations)
  bloc 3   = resume des echanges anciens
  bloc 4   = N derniers messages bruts
  bloc 5   = erreurs de compilation en attente
  user     = prompt courant
"""
from __future__ import annotations

from dataclasses import dataclass, field

from .rag import estimate_tokens

PROTOCOL_RULES = """\
## Protocole de production de fichiers (obligatoire)

Pour chaque fichier a creer ou modifier, ecris exactement :

===FILE: chemin/relatif/depuis/la/racine.cpp ACTION: create===
<contenu COMPLET du fichier>
===END===

Regles imperatives :
1. ACTION vaut create (nouveau fichier), replace (fichier existant) ou delete.
2. Le contenu doit toujours etre le fichier ENTIER, jamais un extrait ni un
   diff, jamais de commentaire du type "... reste inchange ...".
3. Chemins relatifs uniquement, separes par /. Jamais de chemin absolu, jamais de "..".
4. Aucun bloc de code markdown a l'interieur d'un bloc ===FILE:===.
5. Les explications se mettent avant ou apres les blocs, pas dedans.
6. Si tu ne modifies aucun fichier, n'ecris aucun bloc ===FILE:===.
7. Maintiens le CMakeLists.txt a jour des que tu ajoutes ou retires un fichier source.
"""


PROTOCOL_REMINDER = """\
--- RAPPEL DE FORMAT, a respecter pour CETTE reponse ---
Chaque fichier que tu livres, SANS EXCEPTION, prend cette forme exacte :

===FILE: chemin/relatif.cpp ACTION: create===
contenu complet du fichier
===END===

- Le CMakeLists.txt se livre de la meme facon, en entier. Jamais sous forme
  de "lignes a ajouter", jamais dans un bloc markdown.
- Jamais de ``` pour livrer un fichier. Les ``` sont reserves aux exemples
  de commandes a taper dans un terminal.
- Toujours le fichier entier, jamais un extrait, jamais "... inchange ...".
"""


@dataclass
class ContextStats:
    system_tokens: int = 0
    knowledge_tokens: int = 0
    manifest_tokens: int = 0
    summary_tokens: int = 0
    history_tokens: int = 0
    errors_tokens: int = 0
    prompt_tokens: int = 0
    dropped_messages: int = 0

    @property
    def total(self) -> int:
        return (self.system_tokens + self.knowledge_tokens + self.manifest_tokens
                + self.summary_tokens + self.history_tokens + self.errors_tokens
                + self.prompt_tokens)

    def describe(self) -> str:
        return (f"contexte ~{self.total} tokens "
                f"(systeme {self.system_tokens}, savoirs {self.knowledge_tokens}, "
                f"projet {self.manifest_tokens}, resume {self.summary_tokens}, "
                f"historique {self.history_tokens}, erreurs {self.errors_tokens})")


def build_system_prompt(base_prompt: str, project, extra: str = "") -> str:
    parts = [base_prompt.strip(), PROTOCOL_RULES]
    if project is not None:
        fiche = [
            "## Fiche du projet",
            f"- Nom : {project['name']}",
            f"- Racine : {project['path']}",
            f"- Standard C++ : {project['cpp_standard']}",
            f"- Compilateur cible : {project['compiler']}",
            f"- Plateforme : {project['platform']}",
            f"- Systeme de build : {project['build_system']}",
        ]
        style = (project["style_notes"] or "").strip()
        if style:
            fiche.append(f"- Conventions imposees : {style}")
        parts.append("\n".join(fiche))
        custom = (project["system_prompt"] or "").strip()
        if custom:
            parts.append(f"## Consignes specifiques au projet\n{custom}")
    if extra.strip():
        parts.append(extra.strip())
    parts.append(
        "## Compilation\n"
        "Tu ne compiles pas. L'utilisateur compile lui-meme et te transmettra la "
        "sortie du compilateur. Produis donc du code complet, autonome et "
        "compilable en l'etat : includes necessaires, gardes d'en-tete, "
        "declarations avant usage."
    )
    return "\n\n".join(p for p in parts if p.strip())


@dataclass
class BuiltContext:
    messages: list[dict] = field(default_factory=list)
    stats: ContextStats = field(default_factory=ContextStats)


def build_messages(
    system_prompt: str,
    knowledge_block: str,
    manifest_block: str,
    summary_text: str,
    history: list[dict],
    error_block: str,
    user_prompt: str,
    budget_tokens: int,
    keep_last: int,
) -> BuiltContext:
    stats = ContextStats()
    messages: list[dict] = []

    stats.system_tokens = estimate_tokens(system_prompt)
    messages.append({"role": "system", "content": system_prompt})

    if knowledge_block.strip():
        block = ("# Extraits de la base de savoirs (reference, a respecter)\n\n"
                 + knowledge_block.strip())
        stats.knowledge_tokens = estimate_tokens(block)
        messages.append({"role": "system", "content": block})

    if manifest_block.strip():
        block = ("# Etat actuel du projet sur le disque\n\n" + manifest_block.strip()
                 + "\n\nN'invente pas de fichier absent de cette liste : "
                   "cree-le explicitement si necessaire.")
        stats.manifest_tokens = estimate_tokens(block)
        messages.append({"role": "system", "content": block})

    if summary_text.strip():
        block = "# Resume des echanges precedents\n\n" + summary_text.strip()
        stats.summary_tokens = estimate_tokens(block)
        messages.append({"role": "system", "content": block})

    # historique : on garde les derniers messages dans la limite du budget
    fixed = stats.total + estimate_tokens(user_prompt) + estimate_tokens(error_block)
    remaining = max(600, budget_tokens - fixed)
    selected: list[dict] = []
    used = 0
    for message in reversed(history[-max(keep_last, 2) * 2:]):
        cost = estimate_tokens(message["content"])
        if selected and used + cost > remaining:
            break
        if len(selected) >= keep_last and used + cost > remaining // 2:
            break
        selected.append(message)
        used += cost
    selected.reverse()
    stats.dropped_messages = max(0, len(history) - len(selected))
    stats.history_tokens = used
    messages.extend({"role": m["role"], "content": m["content"]} for m in selected)

    if error_block.strip():
        stats.errors_tokens = estimate_tokens(error_block)
        messages.append({
            "role": "user",
            "content": ("Voici la sortie de compilation de la derniere version. "
                        "Corrige les erreurs en renvoyant les fichiers complets.\n\n"
                        + error_block.strip()),
        })

    # Le rappel de protocole est place en DERNIERE position : les petits
    # modeles accordent beaucoup plus de poids aux instructions recentes
    # qu'a celles du prompt systeme, noyees des que le contexte s'allonge.
    final_prompt = user_prompt.rstrip() + "\n\n" + PROTOCOL_REMINDER
    stats.prompt_tokens = estimate_tokens(final_prompt)
    messages.append({"role": "user", "content": final_prompt})
    return BuiltContext(messages=messages, stats=stats)


SUMMARY_INSTRUCTION = """\
Resume les echanges suivants en francais, en moins de 250 mots, sous forme de
puces factuelles. Conserve uniquement ce qui sera utile pour poursuivre le
developpement : objectif du programme, architecture retenue, fichiers crees et
leur role, decisions techniques, contraintes imposees, bugs resolus et restants.
Ne recopie pas de code. Ne commente pas, ne salue pas.
"""


def summary_messages(previous_summary: str, history: list[dict]) -> list[dict]:
    transcript_parts = []
    for message in history:
        role = {"user": "UTILISATEUR", "assistant": "IA"}.get(message["role"], message["role"].upper())
        content = message["content"]
        if len(content) > 1800:
            content = content[:1800] + " ... (tronque)"
        transcript_parts.append(f"{role} : {content}")
    transcript = "\n\n".join(transcript_parts)
    user_content = SUMMARY_INSTRUCTION
    if previous_summary.strip():
        user_content += f"\nResume existant a mettre a jour :\n{previous_summary.strip()}\n"
    user_content += f"\nEchanges :\n{transcript}"
    return [
        {"role": "system", "content": "Tu es un assistant qui redige des resumes techniques concis."},
        {"role": "user", "content": user_content},
    ]


TITLE_INSTRUCTION = (
    "Donne un titre de 3 a 6 mots, en francais, resumant cette demande de "
    "developpement. Reponds uniquement par le titre, sans guillemets ni ponctuation finale."
)


def title_messages(first_prompt: str) -> list[dict]:
    return [
        {"role": "system", "content": "Tu nommes des conversations techniques."},
        {"role": "user", "content": f"{TITLE_INSTRUCTION}\n\nDemande :\n{first_prompt[:800]}"},
    ]

REPAIR_INSTRUCTION = """\
Ta reponse precedente contient du code mais aucun fichier exploitable : le
format de livraison n'a pas ete respecte.

Renvoie MAINTENANT uniquement les fichiers, sans aucune explication, sans
aucun texte avant ou apres, strictement dans ce format :

===FILE: chemin/relatif.cpp ACTION: create===
contenu complet du fichier
===END===

Un bloc par fichier, contenu entier a chaque fois, CMakeLists.txt compris.
"""


def repair_messages(previous_answer: str) -> list[dict]:
    """Demande au modele de re-livrer sa reponse au bon format."""
    return [
        {"role": "system",
         "content": "Tu reformates une reponse existante. Tu ne changes pas le code, "
                    "tu ne commentes pas, tu produis uniquement des blocs de fichiers."},
        {"role": "user", "content": REPAIR_INSTRUCTION
            + "\n\nReponse a reformater :\n\n" + previous_answer},
    ]
