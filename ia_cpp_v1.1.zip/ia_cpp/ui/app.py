"""Fenetre principale de l'application IA C++."""
from __future__ import annotations

import os
import queue
import subprocess
import threading
import time
import tkinter as tk
from pathlib import Path
from tkinter import filedialog, messagebox, scrolledtext, ttk

from core import errors as err
from core import files as fs
from core import gitrepo
from core.config import Config, data_dir, knowledge_dir, log_dir, prompts_dir
from core.db import Database
from core import protocol
from core.engine import Engine
from core.ollama_client import OllamaError

from .dialogs import DiffDialog, ProjectDialog

APP_TITLE = "IA C++ locale - generateur de code assiste par Ollama"


class App(tk.Tk):
    def __init__(self, config: Config, db: Database) -> None:
        super().__init__()
        self.config_obj = config
        self.db = db
        self.engine = Engine(config, db)

        self.events: queue.Queue = queue.Queue()
        self.worker: threading.Thread | None = None
        self.busy = False

        self.project = None
        self.conversation_id: int | None = None
        self.pending_prompt_id: int | None = None
        self.stream_start_index: str | None = None
        self.last_answer: tuple[int, str, str] | None = None

        self.title(APP_TITLE)
        self.geometry("1280x840")
        self.minsize(1040, 680)

        try:
            ttk.Style().theme_use(str(config["theme"]))
        except tk.TclError:
            pass

        self.mono = (str(config["font_mono"]), int(config["font_size"]))
        self.mono_small = (str(config["font_mono"]), max(8, int(config["font_size"]) - 1))

        self._build_toolbar()
        self._build_notebook()
        self._build_statusbar()

        self.protocol("WM_DELETE_WINDOW", self._on_close)
        self.bind("<Control-Return>", lambda _e: self.send_prompt())
        self.bind("<Control-s>", lambda _e: self.save_settings())

        self._reload_projects(select_last=True)
        self.after(80, self._drain_events)
        self.after(300, self._check_ollama_async)

    # ================================================================ barre
    def _build_toolbar(self) -> None:
        bar = ttk.Frame(self, padding=(8, 6))
        bar.pack(fill="x")

        ttk.Label(bar, text="Projet").pack(side="left")
        self.var_project = tk.StringVar()
        self.cmb_project = ttk.Combobox(bar, textvariable=self.var_project, state="readonly",
                                        width=28)
        self.cmb_project.pack(side="left", padx=(4, 2))
        self.cmb_project.bind("<<ComboboxSelected>>", lambda _e: self._on_project_selected())
        ttk.Button(bar, text="+", width=3, command=self.new_project).pack(side="left")
        ttk.Button(bar, text="Modifier", command=self.edit_project).pack(side="left", padx=2)
        ttk.Button(bar, text="Ouvrir le dossier",
                   command=self.open_project_folder).pack(side="left", padx=2)

        ttk.Separator(bar, orient="vertical").pack(side="left", fill="y", padx=10)

        ttk.Label(bar, text="Conversation").pack(side="left")
        self.var_conversation = tk.StringVar()
        self.cmb_conversation = ttk.Combobox(bar, textvariable=self.var_conversation,
                                             state="readonly", width=30)
        self.cmb_conversation.pack(side="left", padx=(4, 2))
        self.cmb_conversation.bind("<<ComboboxSelected>>",
                                   lambda _e: self._on_conversation_selected())
        ttk.Button(bar, text="+", width=3, command=self.new_conversation).pack(side="left")
        ttk.Button(bar, text="Renommer", command=self.rename_conversation).pack(side="left", padx=2)

        self.lbl_model = ttk.Label(bar, text="")
        self.lbl_model.pack(side="right")

    def _build_notebook(self) -> None:
        self.nb = ttk.Notebook(self)
        self.nb.pack(fill="both", expand=True, padx=8, pady=(0, 4))
        self.tab_chat = ttk.Frame(self.nb)
        self.tab_errors = ttk.Frame(self.nb)
        self.tab_files = ttk.Frame(self.nb)
        self.tab_knowledge = ttk.Frame(self.nb)
        self.tab_settings = ttk.Frame(self.nb)
        self.nb.add(self.tab_chat, text="  Developpement  ")
        self.nb.add(self.tab_errors, text="  Erreurs de compilation  ")
        self.nb.add(self.tab_files, text="  Fichiers  ")
        self.nb.add(self.tab_knowledge, text="  Savoirs  ")
        self.nb.add(self.tab_settings, text="  Parametres  ")
        self._build_chat_tab()
        self._build_errors_tab()
        self._build_files_tab()
        self._build_knowledge_tab()
        self._build_settings_tab()

    def _build_statusbar(self) -> None:
        bar = ttk.Frame(self, padding=(8, 4))
        bar.pack(fill="x")
        self.var_status = tk.StringVar(value="Pret.")
        ttk.Label(bar, textvariable=self.var_status).pack(side="left")
        self.progress = ttk.Progressbar(bar, mode="indeterminate", length=160)
        self.progress.pack(side="right")
        self.var_context = tk.StringVar(value="")
        ttk.Label(bar, textvariable=self.var_context).pack(side="right", padx=12)

    # ========================================================= onglet chat
    def _build_chat_tab(self) -> None:
        panes = ttk.Panedwindow(self.tab_chat, orient="vertical")
        panes.pack(fill="both", expand=True, pady=6)

        top = ttk.Frame(panes)
        self.txt_chat = scrolledtext.ScrolledText(top, wrap="word", font=self.mono,
                                                  state="disabled", background="#fbfbfb")
        self.txt_chat.pack(fill="both", expand=True)
        for tag, options in {
            "user": {"foreground": "#14387a", "font": (self.mono[0], self.mono[1], "bold")},
            "assistant": {"foreground": "#111111"},
            "system": {"foreground": "#6a6a6a", "font": (self.mono[0], self.mono_small[1], "italic")},
            "ok": {"foreground": "#0a6b2d"},
            "fail": {"foreground": "#a3141b"},
            "file": {"foreground": "#7a4b00"},
        }.items():
            self.txt_chat.tag_configure(tag, **options)
        panes.add(top, weight=4)

        bottom = ttk.Frame(panes)
        self.txt_prompt = tk.Text(bottom, height=7, wrap="word", font=self.mono)
        self.txt_prompt.pack(fill="both", expand=True, pady=(6, 4))
        self.txt_prompt.bind("<KeyRelease>", lambda _e: self._update_prompt_estimate())

        controls = ttk.Frame(bottom)
        controls.pack(fill="x")
        self.btn_send = ttk.Button(controls, text="Envoyer  (Ctrl+Entree)",
                                   command=self.send_prompt)
        self.btn_send.pack(side="left")
        self.btn_stop = ttk.Button(controls, text="Stop", command=self.stop_generation,
                                   state="disabled")
        self.btn_stop.pack(side="left", padx=6)

        self.var_rag = tk.BooleanVar(value=True)
        self.var_manifest = tk.BooleanVar(value=True)
        ttk.Checkbutton(controls, text="Base de savoirs",
                        variable=self.var_rag).pack(side="left", padx=(14, 4))
        ttk.Checkbutton(controls, text="Etat du projet",
                        variable=self.var_manifest).pack(side="left", padx=4)
        self.btn_reformat = ttk.Button(controls, text="Reformater en fichiers",
                                       command=self.reformat_last, state="disabled")
        self.btn_reformat.pack(side="left", padx=10)
        ttk.Button(controls, text="Resumer l'historique",
                   command=self.force_summary).pack(side="left", padx=4)
        ttk.Button(controls, text="Effacer l'affichage",
                   command=lambda: self._clear_chat_view()).pack(side="left")

        self.var_prompt_estimate = tk.StringVar(value="0 token estime")
        ttk.Label(controls, textvariable=self.var_prompt_estimate).pack(side="right")
        panes.add(bottom, weight=1)

    # ====================================================== onglet erreurs
    def _build_errors_tab(self) -> None:
        frame = ttk.Frame(self.tab_errors, padding=6)
        frame.pack(fill="both", expand=True)
        frame.rowconfigure(1, weight=3)
        frame.rowconfigure(4, weight=2)
        frame.columnconfigure(0, weight=1)

        ttk.Label(frame, text="Colle ici la sortie complete du compilateur "
                              "(MSVC, GCC/Clang, CMake, linker) :").grid(row=0, column=0, sticky="w")
        self.txt_build = scrolledtext.ScrolledText(frame, wrap="none", font=self.mono_small,
                                                   height=14)
        self.txt_build.grid(row=1, column=0, sticky="nsew", pady=4)

        buttons = ttk.Frame(frame)
        buttons.grid(row=2, column=0, sticky="ew", pady=4)
        ttk.Button(buttons, text="Analyser", command=self.analyse_build).pack(side="left")
        ttk.Button(buttons, text="Analyser et demander la correction",
                   command=self.fix_build).pack(side="left", padx=6)
        ttk.Button(buttons, text="Tout marquer resolu",
                   command=self.clear_errors).pack(side="left", padx=6)
        ttk.Button(buttons, text="Vider la zone",
                   command=lambda: self.txt_build.delete("1.0", "end")).pack(side="left")
        self.var_build_summary = tk.StringVar(value="")
        ttk.Label(buttons, textvariable=self.var_build_summary).pack(side="right")

        ttk.Label(frame, text="Problemes identifies :").grid(row=3, column=0, sticky="w")
        columns = ("kind", "code", "file", "line", "text")
        self.tree_errors = ttk.Treeview(frame, columns=columns, show="headings", height=10)
        for key, label, width, anchor in (
            ("kind", "Type", 80, "center"),
            ("code", "Code", 80, "center"),
            ("file", "Fichier", 260, "w"),
            ("line", "Ligne", 60, "center"),
            ("text", "Message", 620, "w"),
        ):
            self.tree_errors.heading(key, text=label)
            self.tree_errors.column(key, width=width, anchor=anchor)
        scroll = ttk.Scrollbar(frame, orient="vertical", command=self.tree_errors.yview)
        self.tree_errors.configure(yscrollcommand=scroll.set)
        self.tree_errors.grid(row=4, column=0, sticky="nsew", pady=4)
        scroll.grid(row=4, column=1, sticky="ns")

    # ===================================================== onglet fichiers
    def _build_files_tab(self) -> None:
        frame = ttk.Frame(self.tab_files, padding=6)
        frame.pack(fill="both", expand=True)
        frame.rowconfigure(1, weight=1)
        frame.columnconfigure(0, weight=1)
        frame.columnconfigure(1, weight=1)

        ttk.Label(frame, text="Fichiers presents dans le projet").grid(row=0, column=0, sticky="w")
        self.tree_project = ttk.Treeview(frame, columns=("path", "size"), show="headings")
        self.tree_project.heading("path", text="Chemin")
        self.tree_project.heading("size", text="Octets")
        self.tree_project.column("path", width=420, anchor="w")
        self.tree_project.column("size", width=90, anchor="e")
        self.tree_project.grid(row=1, column=0, sticky="nsew", padx=(0, 6))
        self.tree_project.bind("<Double-1>", lambda _e: self.open_selected_file())

        ttk.Label(frame, text="Historique des ecritures de l'IA").grid(row=0, column=1, sticky="w")
        self.tree_history = ttk.Treeview(frame, columns=("when", "path", "action", "version"),
                                         show="headings")
        for key, label, width, anchor in (
            ("when", "Date", 130, "w"),
            ("path", "Fichier", 280, "w"),
            ("action", "Action", 90, "center"),
            ("version", "Ver.", 50, "center"),
        ):
            self.tree_history.heading(key, text=label)
            self.tree_history.column(key, width=width, anchor=anchor)
        self.tree_history.grid(row=1, column=1, sticky="nsew")

        buttons = ttk.Frame(frame)
        buttons.grid(row=2, column=0, columnspan=2, sticky="ew", pady=6)
        ttk.Button(buttons, text="Rafraichir", command=self.refresh_files).pack(side="left")
        ttk.Button(buttons, text="Ouvrir le fichier",
                   command=self.open_selected_file).pack(side="left", padx=6)
        ttk.Button(buttons, text="Restaurer la sauvegarde selectionnee",
                   command=self.restore_selected).pack(side="left", padx=6)
        ttk.Button(buttons, text="Annuler le dernier commit git",
                   command=self.revert_git).pack(side="left", padx=6)

        ttk.Label(frame, text="Journal git recent :").grid(row=3, column=0, sticky="w")
        self.txt_git = tk.Text(frame, height=8, font=self.mono_small, state="disabled")
        self.txt_git.grid(row=4, column=0, columnspan=2, sticky="nsew", pady=(2, 0))

    # ====================================================== onglet savoirs
    def _build_knowledge_tab(self) -> None:
        frame = ttk.Frame(self.tab_knowledge, padding=6)
        frame.pack(fill="both", expand=True)
        frame.rowconfigure(1, weight=2)
        frame.rowconfigure(5, weight=1)
        frame.columnconfigure(0, weight=1)

        ttk.Label(frame, text="Packs de savoirs (coche = actif pour le projet courant)").grid(
            row=0, column=0, sticky="w")
        self.tree_packs = ttk.Treeview(frame, columns=("sel", "name", "chunks", "model", "desc"),
                                       show="headings", height=10)
        for key, label, width, anchor in (
            ("sel", "", 36, "center"),
            ("name", "Pack", 220, "w"),
            ("chunks", "Extraits", 80, "center"),
            ("model", "Modele d'embedding", 170, "w"),
            ("desc", "Description", 520, "w"),
        ):
            self.tree_packs.heading(key, text=label)
            self.tree_packs.column(key, width=width, anchor=anchor)
        self.tree_packs.grid(row=1, column=0, sticky="nsew", pady=4)
        self.tree_packs.bind("<Button-1>", self._on_pack_click)
        self.tree_packs.bind("<space>", lambda _e: self._toggle_pack())

        buttons = ttk.Frame(frame)
        buttons.grid(row=2, column=0, sticky="ew", pady=4)
        ttk.Button(buttons, text="Indexer le dossier knowledge/",
                   command=lambda: self.ingest_knowledge(False)).pack(side="left")
        ttk.Button(buttons, text="Forcer la reindexation",
                   command=lambda: self.ingest_knowledge(True)).pack(side="left", padx=6)
        ttk.Button(buttons, text="Ajouter un document...",
                   command=self.add_knowledge_file).pack(side="left", padx=6)
        ttk.Button(buttons, text="Ouvrir le dossier knowledge/",
                   command=lambda: self._open_path(knowledge_dir())).pack(side="left", padx=6)
        ttk.Button(buttons, text="Supprimer le pack",
                   command=self.delete_pack).pack(side="left", padx=6)

        ttk.Label(frame, text="Tester une recherche dans les savoirs :").grid(row=3, column=0,
                                                                             sticky="w")
        search = ttk.Frame(frame)
        search.grid(row=4, column=0, sticky="ew", pady=4)
        self.var_search = tk.StringVar()
        entry = ttk.Entry(search, textvariable=self.var_search)
        entry.pack(side="left", fill="x", expand=True)
        entry.bind("<Return>", lambda _e: self.search_knowledge())
        ttk.Button(search, text="Chercher", command=self.search_knowledge).pack(side="left", padx=6)

        self.txt_search = scrolledtext.ScrolledText(frame, height=12, wrap="word",
                                                    font=self.mono_small, state="disabled")
        self.txt_search.grid(row=5, column=0, sticky="nsew")

    # =================================================== onglet parametres
    def _build_settings_tab(self) -> None:
        outer = ttk.Frame(self.tab_settings, padding=10)
        outer.pack(fill="both", expand=True)
        outer.columnconfigure(1, weight=1)

        self.setting_vars: dict[str, tk.Variable] = {}
        row = 0

        def add_entry(key: str, label: str, width: int = 40):
            nonlocal row
            ttk.Label(outer, text=label).grid(row=row, column=0, sticky="w", pady=3)
            var = tk.StringVar(value=str(self.config_obj[key]))
            ttk.Entry(outer, textvariable=var, width=width).grid(row=row, column=1, sticky="w",
                                                                 pady=3)
            self.setting_vars[key] = var
            row += 1
            return var

        def add_combo(key: str, label: str):
            nonlocal row
            ttk.Label(outer, text=label).grid(row=row, column=0, sticky="w", pady=3)
            var = tk.StringVar(value=str(self.config_obj[key]))
            combo = ttk.Combobox(outer, textvariable=var, width=38, values=[])
            combo.grid(row=row, column=1, sticky="w", pady=3)
            self.setting_vars[key] = var
            self.model_combos.append(combo)
            row += 1
            return var

        def add_check(key: str, label: str):
            nonlocal row
            var = tk.BooleanVar(value=bool(self.config_obj[key]))
            ttk.Checkbutton(outer, text=label, variable=var).grid(row=row, column=0, columnspan=2,
                                                                  sticky="w", pady=3)
            self.setting_vars[key] = var
            row += 1
            return var

        self.model_combos: list[ttk.Combobox] = []

        ttk.Label(outer, text="Ollama", font=(self.mono[0], self.mono[1] + 1, "bold")).grid(
            row=row, column=0, sticky="w", pady=(0, 6))
        row += 1
        add_entry("ollama_url", "URL du serveur")
        add_combo("model_code", "Modele de generation de code")
        add_combo("model_light", "Modele leger (resumes, titres)")
        add_combo("model_embed", "Modele d'embeddings")
        add_entry("temperature_code", "Temperature code", 12)
        add_entry("temperature_light", "Temperature modele leger", 12)
        add_entry("num_ctx", "Fenetre de contexte du modele (num_ctx)", 12)
        add_entry("request_timeout", "Timeout requete (s)", 12)

        ttk.Separator(outer, orient="horizontal").grid(row=row, column=0, columnspan=2,
                                                       sticky="ew", pady=8)
        row += 1
        ttk.Label(outer, text="Contexte et savoirs",
                  font=(self.mono[0], self.mono[1] + 1, "bold")).grid(row=row, column=0,
                                                                      sticky="w", pady=(0, 6))
        row += 1
        add_entry("context_budget_tokens", "Budget de contexte (tokens)", 12)
        add_entry("keep_last_messages", "Messages bruts conserves", 12)
        add_entry("summarize_after_messages", "Resumer au-dela de N messages", 12)
        add_entry("rag_top_k", "Extraits de savoirs injectes", 12)

        ttk.Separator(outer, orient="horizontal").grid(row=row, column=0, columnspan=2,
                                                       sticky="ew", pady=8)
        row += 1
        ttk.Label(outer, text="Securite et versionnement",
                  font=(self.mono[0], self.mono[1] + 1, "bold")).grid(row=row, column=0,
                                                                      sticky="w", pady=(0, 6))
        row += 1
        add_check("require_diff_approval", "Toujours afficher la revue de diff avant ecriture")
        add_check("backup_before_write", "Sauvegarder l'ancienne version avant ecrasement")
        add_check("git_enabled", "Utiliser git dans le dossier projet")
        add_check("git_auto_commit", "Commit automatique apres chaque application")
        add_entry("max_file_bytes", "Taille maximale d'un fichier ecrit (octets)", 12)
        add_entry("max_manifest_files", "Fichiers maximum dans le manifeste", 12)

        ttk.Separator(outer, orient="horizontal").grid(row=row, column=0, columnspan=2,
                                                       sticky="ew", pady=8)
        row += 1
        buttons = ttk.Frame(outer)
        buttons.grid(row=row, column=0, columnspan=2, sticky="w")
        ttk.Button(buttons, text="Enregistrer  (Ctrl+S)",
                   command=self.save_settings).pack(side="left")
        ttk.Button(buttons, text="Tester la connexion Ollama",
                   command=self._check_ollama_async).pack(side="left", padx=6)
        ttk.Button(buttons, text="Recharger la liste des modeles",
                   command=self._load_models_async).pack(side="left", padx=6)
        ttk.Button(buttons, text="Ouvrir le dossier des prompts",
                   command=lambda: self._open_path(prompts_dir())).pack(side="left", padx=6)
        ttk.Button(buttons, text="Ouvrir les journaux",
                   command=lambda: self._open_path(log_dir())).pack(side="left", padx=6)
        row += 1
        ttk.Label(outer, text=f"Donnees : {data_dir()}").grid(row=row, column=0, columnspan=2,
                                                              sticky="w", pady=(10, 0))

    # ============================================================= projets
    def _reload_projects(self, select_last: bool = False) -> None:
        self.projects = list(self.db.list_projects())
        names = [row["name"] for row in self.projects]
        self.cmb_project.configure(values=names)
        if not self.projects:
            self.var_project.set("")
            self.project = None
            self.conversation_id = None
            self.cmb_conversation.configure(values=[])
            self.var_conversation.set("")
            self._set_status("Aucun projet. Clique sur + pour en creer un.")
            return
        target = names[0]
        if select_last:
            last = self.db.get_setting("last_project")
            if last in names:
                target = last
        self.var_project.set(target)
        self._on_project_selected()

    def _on_project_selected(self) -> None:
        name = self.var_project.get()
        match = next((row for row in self.projects if row["name"] == name), None)
        if match is None:
            return
        self.project = match
        self.db.set_setting("last_project", name)
        self._reload_conversations()
        self.refresh_files()
        self.refresh_packs()
        self.refresh_errors()
        self._update_model_label()

    def new_project(self) -> None:
        dialog = ProjectDialog(self, "Nouveau projet")
        self.wait_window(dialog)
        if not dialog.result:
            return
        try:
            project_id = self.db.create_project(dialog.result.pop("name"),
                                                dialog.result.pop("path"), **dialog.result)
        except Exception as exc:  # nom deja pris, etc.
            messagebox.showerror("Projet", f"Creation impossible : {exc}")
            return
        project = self.db.get_project(project_id)
        self.db.create_conversation(project_id, "Premiere conversation")
        if self.config_obj["git_enabled"]:
            ok, info = gitrepo.ensure_repo(project["path"])
            self._set_status(f"Projet cree. {info}" if ok else f"Projet cree. git : {info}")
        self._reload_projects()
        self.var_project.set(project["name"])
        self._on_project_selected()

    def edit_project(self) -> None:
        if not self._require_project():
            return
        dialog = ProjectDialog(self, "Modifier le projet", self.project)
        self.wait_window(dialog)
        if not dialog.result:
            return
        self.db.update_project(int(self.project["id"]), **dialog.result)
        self._reload_projects()
        self.var_project.set(dialog.result["name"])
        self._on_project_selected()
        self._set_status("Projet mis a jour.")

    def open_project_folder(self) -> None:
        if not self._require_project():
            return
        self._open_path(Path(self.project["path"]))

    # ======================================================= conversations
    def _reload_conversations(self) -> None:
        if not self.project:
            return
        self.conversations = list(self.db.list_conversations(int(self.project["id"])))
        if not self.conversations:
            self.db.create_conversation(int(self.project["id"]))
            self.conversations = list(self.db.list_conversations(int(self.project["id"])))
        labels = [f"{row['id']} - {row['title']}" for row in self.conversations]
        self.cmb_conversation.configure(values=labels)
        self.var_conversation.set(labels[0])
        self._on_conversation_selected()

    def _on_conversation_selected(self) -> None:
        label = self.var_conversation.get()
        if not label:
            return
        try:
            conversation_id = int(label.split(" - ", 1)[0])
        except ValueError:
            return
        self.conversation_id = conversation_id
        self._render_conversation()

    def new_conversation(self) -> None:
        if not self._require_project():
            return
        self.db.create_conversation(int(self.project["id"]))
        self._reload_conversations()
        self._set_status("Nouvelle conversation creee.")

    def rename_conversation(self) -> None:
        if self.conversation_id is None:
            return
        current = self.var_conversation.get().split(" - ", 1)[-1]
        dialog = tk.Toplevel(self)
        dialog.title("Renommer la conversation")
        dialog.transient(self)
        var = tk.StringVar(value=current)
        ttk.Label(dialog, text="Nouveau titre :").pack(padx=12, pady=(12, 4))
        entry = ttk.Entry(dialog, textvariable=var, width=46)
        entry.pack(padx=12)
        entry.focus_set()

        def confirm() -> None:
            title = var.get().strip()
            if title:
                self.db.rename_conversation(int(self.conversation_id), title)
                self._reload_conversations()
            dialog.destroy()

        buttons = ttk.Frame(dialog)
        buttons.pack(pady=12)
        ttk.Button(buttons, text="Valider", command=confirm).pack(side="left", padx=4)
        ttk.Button(buttons, text="Annuler", command=dialog.destroy).pack(side="left")
        entry.bind("<Return>", lambda _e: confirm())
        dialog.grab_set()

    # ========================================================== affichage
    def _clear_chat_view(self) -> None:
        self.txt_chat.configure(state="normal")
        self.txt_chat.delete("1.0", "end")
        self.txt_chat.configure(state="disabled")

    def _append(self, text: str, tag: str = "assistant") -> str:
        self.txt_chat.configure(state="normal")
        start = self.txt_chat.index("end-1c")
        self.txt_chat.insert("end", text, tag)
        self.txt_chat.see("end")
        self.txt_chat.configure(state="disabled")
        return start

    def _render_conversation(self) -> None:
        self._clear_chat_view()
        if self.conversation_id is None:
            return
        summary = self.db.latest_summary(int(self.conversation_id))
        if summary:
            self._append("--- resume des echanges anciens ---\n", "system")
            self._append(summary["content"].strip() + "\n\n", "system")
        for row in self.db.list_messages(int(self.conversation_id)):
            stamp = time.strftime("%d/%m %H:%M", time.localtime(row["created_at"]))
            if row["role"] == "user":
                self._append(f"\n[{stamp}] Vous\n", "user")
                self._append(row["content"].strip() + "\n", "assistant")
            else:
                self._append(f"\n[{stamp}] IA ({row['model']})\n", "user")
                self._append(row["content"].strip() + "\n", "assistant")
        self._update_prompt_estimate()

    def _update_prompt_estimate(self) -> None:
        text = self.txt_prompt.get("1.0", "end")
        self.var_prompt_estimate.set(f"{self.engine.estimate(text)} tokens estimes")

    def _set_status(self, text: str) -> None:
        self.var_status.set(text)

    def _update_model_label(self) -> None:
        self.lbl_model.configure(
            text=f"code : {self.config_obj['model_code']}   |   "
                 f"leger : {self.config_obj['model_light']}   |   "
                 f"embed : {self.config_obj['model_embed']}"
        )

    # ========================================================== generation
    def send_prompt(self, prompt_override: str | None = None) -> None:
        if self.busy:
            messagebox.showinfo("Generation", "Une generation est deja en cours.")
            return
        if not self._require_project():
            return
        if self.conversation_id is None:
            self._reload_conversations()
        prompt = prompt_override if prompt_override is not None else \
            self.txt_prompt.get("1.0", "end").strip()
        if not prompt:
            return
        if not Path(self.project["path"]).exists():
            messagebox.showerror("Projet", f"Le dossier projet est introuvable :\n"
                                           f"{self.project['path']}")
            return

        if prompt_override is None:
            self.txt_prompt.delete("1.0", "end")
        self._update_prompt_estimate()

        message_id = self.db.add_message(int(self.conversation_id), "user", prompt,
                                         tokens_est=self.engine.estimate(prompt))
        self.pending_prompt_id = message_id
        stamp = time.strftime("%d/%m %H:%M")
        self._append(f"\n[{stamp}] Vous\n", "user")
        self._append(prompt.strip() + "\n", "assistant")
        self._append(f"\n[{stamp}] IA ({self.config_obj['model_code']})\n", "user")
        self.stream_start_index = self.txt_chat.index("end-1c")

        self._set_busy(True, "Generation en cours...")
        project = self.project
        conversation_id = int(self.conversation_id)
        use_rag = bool(self.var_rag.get())
        use_manifest = bool(self.var_manifest.get())
        first_message = self.db.count_messages(conversation_id) <= 1

        def task() -> None:
            try:
                result = self.engine.generate(
                    project, conversation_id, prompt,
                    on_chunk=lambda piece: self.events.put(("chunk", piece)),
                    use_rag=use_rag, use_manifest=use_manifest,
                )
                self.events.put(("done", (result, conversation_id, first_message, prompt)))
            except Exception as exc:  # pragma: no cover - securite runtime
                self.events.put(("error", str(exc)))

        self.worker = threading.Thread(target=task, daemon=True)
        self.worker.start()

    def stop_generation(self) -> None:
        self.engine.stop()
        self._set_status("Arret demande...")

    def _set_busy(self, busy: bool, status: str = "") -> None:
        self.busy = busy
        self.btn_send.configure(state="disabled" if busy else "normal")
        self.btn_stop.configure(state="normal" if busy else "disabled")
        if busy:
            self.progress.start(14)
        else:
            self.progress.stop()
        if status:
            self._set_status(status)

    def _drain_events(self) -> None:
        try:
            while True:
                kind, payload = self.events.get_nowait()
                if kind == "chunk":
                    self._append(payload, "assistant")
                elif kind == "status":
                    self._set_status(str(payload))
                elif kind == "error":
                    self._set_busy(False, "Erreur.")
                    self._append(f"\n[erreur] {payload}\n", "fail")
                    messagebox.showerror("Erreur", str(payload))
                elif kind == "done":
                    self._on_generation_done(*payload)
                elif kind == "packs":
                    self.refresh_packs()
                    self._set_busy(False, str(payload))
                elif kind == "models":
                    self._apply_model_list(payload)
                elif kind == "reformat":
                    self._on_reformat_done(*payload)
                elif kind == "search":
                    self._show_search(str(payload))
                elif kind == "summary":
                    self._set_status(str(payload))
                    self._render_conversation()
        except queue.Empty:
            pass
        self.after(80, self._drain_events)

    def _on_generation_done(self, result, conversation_id: int,
                            first_message: bool, prompt: str) -> None:
        self._set_busy(False)
        if result.error:
            self._append(f"\n[erreur Ollama] {result.error}\n", "fail")
            self._set_status("Echec de la generation.")
            return

        # remplace le flux brut par la version nettoyee (blocs fichiers resumes)
        if self.stream_start_index:
            self.txt_chat.configure(state="normal")
            self.txt_chat.delete(self.stream_start_index, "end-1c")
            self.txt_chat.insert(self.stream_start_index,
                                 (result.display_text or "(reponse vide)") + "\n", "assistant")
            self.txt_chat.configure(state="disabled")
            self.stream_start_index = None

        message_id = self.db.add_message(
            conversation_id, "assistant", result.display_text or result.raw_text,
            model=result.model, tokens_est=self.engine.estimate(result.raw_text),
            meta={"files": [op.path for op in result.ops], "stopped": result.stopped},
        )

        if result.stats:
            self.var_context.set(result.stats.describe())
        self._set_status(f"Reponse en {result.duration:.1f} s. "
                         f"{len(result.ops)} fichier(s) proposes."
                         + ("  (generation interrompue)" if result.stopped else ""))

        self.last_answer = (message_id, result.display_text or result.raw_text, prompt)
        self.btn_reformat.configure(state="normal")

        if result.repaired:
            self._append("[-- fichiers recuperes apres reformatage automatique --]\n", "system")

        if result.ops:
            self._review_and_apply(result.ops, message_id, prompt)
        elif protocol.looks_like_code_answer(result.display_text or result.raw_text):
            self._append(
                "\n[-- ATTENTION : aucun fichier reconnu dans cette reponse, "
                "rien n'a ete ecrit sur le disque. "
                "Utilise le bouton « Reformater en fichiers ». --]\n", "fail")
            self._set_status("Aucun fichier reconnu : rien n'a ete ecrit.")
        if self.db.open_errors(int(self.project["id"])):
            self.engine.clear_build_errors(self.project)
            self.refresh_errors()

        if first_message:
            threading.Thread(target=self._title_task,
                             args=(conversation_id, prompt), daemon=True).start()
        threading.Thread(target=self._summary_task,
                         args=(conversation_id,), daemon=True).start()

    def _review_and_apply(self, ops, message_id: int, prompt: str) -> None:
        accepted = ops
        if self.config_obj["require_diff_approval"]:
            dialog = DiffDialog(self, self.project["path"], ops,
                                str(self.config_obj["font_mono"]),
                                int(self.config_obj["font_size"]))
            self.wait_window(dialog)
            accepted = dialog.accepted
            if not accepted:
                self._append("\n[-- aucune modification appliquee (revue annulee) --]\n", "system")
                self._set_status("Modifications refusees : rien n'a ete ecrit.")
                return

        label = prompt.strip().splitlines()[0][:90] if prompt.strip() else "generation IA"
        results, git_message = self.engine.apply_ops(
            self.project, accepted, message_id, f"IA C++ : {label}")
        self._append("\n", "system")
        for result in results:
            tag = "ok" if result.ok else "fail"
            prefix = "OK  " if result.ok else "KO  "
            self._append(f"{prefix}{result.action:8s} {result.path} - {result.message}\n", tag)
        if git_message:
            self._append(f"{git_message}\n", "system")
        self.refresh_files()
        written = sum(1 for r in results if r.ok)
        self._set_status(f"{written}/{len(results)} fichier(s) ecrits. "
                         "Compile puis colle la sortie dans l'onglet Erreurs.")

    def _title_task(self, conversation_id: int, prompt: str) -> None:
        title = self.engine.suggest_title(prompt)
        if title:
            self.db.rename_conversation(conversation_id, title)
            self.events.put(("status", f"Conversation renommee : {title}"))

    def _summary_task(self, conversation_id: int) -> None:
        text = self.engine.maybe_summarise(conversation_id)
        if text:
            self.events.put(("status", "Historique resume pour tenir dans le contexte."))

    def reformat_last(self) -> None:
        if self.busy or not self.last_answer or not self._require_project():
            return
        message_id, answer, prompt = self.last_answer
        self._set_busy(True, "Demande de reformatage au modele...")

        def task() -> None:
            ops, error = self.engine.reformat(answer)
            self.events.put(("reformat", (ops, error, message_id, prompt)))

        threading.Thread(target=task, daemon=True).start()

    def _on_reformat_done(self, ops, error: str, message_id: int, prompt: str) -> None:
        self._set_busy(False)
        if error:
            self._append(f"\n[erreur de reformatage] {error}\n", "fail")
            return
        if not ops:
            self._append("\n[-- le reformatage n'a produit aucun fichier exploitable. "
                         "Reformule la demande ou essaie un autre modele. --]\n", "fail")
            self._set_status("Reformatage sans resultat.")
            return
        self._append(f"\n[-- {len(ops)} fichier(s) recuperes par reformatage --]\n", "ok")
        self._review_and_apply(ops, message_id, prompt)

    def force_summary(self) -> None:
        if self.conversation_id is None:
            return
        self._set_status("Resume en cours...")
        conversation_id = int(self.conversation_id)

        def task() -> None:
            text = self.engine.maybe_summarise(conversation_id, force=True)
            self.events.put(("summary", text and "Resume mis a jour." or "Rien a resumer."))

        threading.Thread(target=task, daemon=True).start()

    # ====================================================== erreurs build
    def analyse_build(self) -> list:
        if not self._require_project():
            return []
        raw = self.txt_build.get("1.0", "end").strip()
        if not raw:
            messagebox.showinfo("Erreurs", "La zone est vide.")
            return []
        issues = self.engine.register_build_output(self.project, raw)
        self.var_build_summary.set(err.summarise(issues))
        self.refresh_errors()
        return issues

    def fix_build(self) -> None:
        issues = self.analyse_build()
        if not issues:
            if not messagebox.askyesno("Erreurs",
                                       "Aucune erreur reconnue automatiquement. "
                                       "Envoyer quand meme le texte brut a l'IA ?"):
                return
        self.nb.select(self.tab_chat)
        self.send_prompt("Corrige les erreurs de compilation ci-dessus. Renvoie les fichiers "
                         "complets concernes et explique brievement la cause de chaque erreur.")

    def clear_errors(self) -> None:
        if not self._require_project():
            return
        self.engine.clear_build_errors(self.project)
        self.refresh_errors()
        self.var_build_summary.set("")
        self._set_status("Erreurs marquees comme resolues.")

    def refresh_errors(self) -> None:
        for item in self.tree_errors.get_children():
            self.tree_errors.delete(item)
        if not self.project:
            return
        for row in self.db.open_errors(int(self.project["id"])):
            self.tree_errors.insert("", "end", values=(row["kind"], row["code"], row["file"],
                                                       row["line"] or "", row["text"]))

    # ========================================================= fichiers
    def refresh_files(self) -> None:
        for item in self.tree_project.get_children():
            self.tree_project.delete(item)
        for item in self.tree_history.get_children():
            self.tree_history.delete(item)
        self.txt_git.configure(state="normal")
        self.txt_git.delete("1.0", "end")
        self.txt_git.configure(state="disabled")
        if not self.project:
            return
        for entry in fs.scan_project(self.project["path"],
                                     list(self.config_obj["allowed_extensions"]),
                                     list(self.config_obj["allowed_filenames"]),
                                     int(self.config_obj["max_manifest_files"])):
            self.tree_project.insert("", "end", values=(entry["path"], entry["size"]))
        for row in self.db.list_files(int(self.project["id"]), 300):
            stamp = time.strftime("%d/%m %H:%M", time.localtime(row["created_at"]))
            self.tree_history.insert("", "end", iid=str(row["id"]),
                                     values=(stamp, row["rel_path"], row["action"],
                                             row["version"]))
        log = gitrepo.log_recent(self.project["path"], 20)
        status = gitrepo.status_short(self.project["path"])
        text = ""
        if log:
            text += log
        if status:
            text += "\n\nModifications non committees :\n" + status
        if not text:
            text = "(pas de depot git dans ce projet)"
        self.txt_git.configure(state="normal")
        self.txt_git.insert("1.0", text)
        self.txt_git.configure(state="disabled")

    def open_selected_file(self) -> None:
        if not self.project:
            return
        selection = self.tree_project.selection()
        if not selection:
            return
        rel = self.tree_project.item(selection[0], "values")[0]
        self._open_path(Path(self.project["path"]) / rel)

    def restore_selected(self) -> None:
        if not self.project:
            return
        selection = self.tree_history.selection()
        if not selection:
            messagebox.showinfo("Restauration",
                                "Selectionne une ligne dans l'historique des ecritures.")
            return
        row = self.db.query_one("SELECT * FROM generated_files WHERE id=?", (int(selection[0]),))
        if not row or not row["backup"]:
            messagebox.showinfo("Restauration",
                                "Aucune sauvegarde associee a cette ligne "
                                "(fichier cree ex nihilo).")
            return
        if not messagebox.askyesno("Restauration",
                                   f"Restaurer la version precedente de\n{row['rel_path']} ?"):
            return
        ok = fs.restore_backup(self.project["path"], row["backup"], row["rel_path"])
        self._set_status("Version restauree." if ok else "Sauvegarde introuvable.")
        self.refresh_files()

    def revert_git(self) -> None:
        if not self.project:
            return
        if not messagebox.askyesno("Git", "Annuler le dernier commit et restaurer l'etat "
                                          "precedent des fichiers ?"):
            return
        ok, info = gitrepo.revert_last(self.project["path"])
        self._set_status(info)
        self.refresh_files()

    # ========================================================== savoirs
    def refresh_packs(self) -> None:
        for item in self.tree_packs.get_children():
            self.tree_packs.delete(item)
        if not self.project:
            return
        state = self.db.project_pack_state(int(self.project["id"]))
        for pack in self.engine.knowledge.stats():
            mark = "[x]" if state.get(pack["id"], True) else "[ ]"
            self.tree_packs.insert("", "end", iid=str(pack["id"]),
                                   values=(mark, pack["name"], pack["chunks"],
                                           pack["embed_model"], pack["description"]))

    def _on_pack_click(self, event) -> None:
        if self.tree_packs.identify_region(event.x, event.y) != "cell":
            return
        if self.tree_packs.identify_column(event.x) != "#1":
            return
        item = self.tree_packs.identify_row(event.y)
        if item:
            self._toggle_pack(item)

    def _toggle_pack(self, item: str | None = None) -> None:
        if not self.project:
            return
        if item is None:
            selection = self.tree_packs.selection()
            if not selection:
                return
            item = selection[0]
        values = list(self.tree_packs.item(item, "values"))
        enabled = values[0] != "[x]"
        values[0] = "[x]" if enabled else "[ ]"
        self.tree_packs.item(item, values=values)
        self.db.set_project_pack(int(self.project["id"]), int(item), enabled)

    def ingest_knowledge(self, force: bool) -> None:
        if self.busy:
            return
        self._set_busy(True, "Indexation des savoirs...")
        directory = knowledge_dir()

        def task() -> None:
            try:
                results = self.engine.knowledge.ingest_directory(
                    directory, progress=lambda m: self.events.put(("status", m)), force=force)
                done = ", ".join(f"{r['pack']} ({r['status']}, {r['chunks']})" for r in results)
                self.events.put(("packs", f"Indexation terminee : {done or 'aucun document'}"))
            except OllamaError as exc:
                self.events.put(("packs", f"Indexation partielle : {exc}"))
            except Exception as exc:  # pragma: no cover
                self.events.put(("packs", f"Echec de l'indexation : {exc}"))

        threading.Thread(target=task, daemon=True).start()

    def add_knowledge_file(self) -> None:
        paths = filedialog.askopenfilenames(
            parent=self, title="Documents a ajouter aux savoirs",
            filetypes=[("Documents texte", "*.md *.txt"), ("Tous", "*.*")])
        if not paths:
            return
        target = knowledge_dir()
        copied = []
        for raw in paths:
            source = Path(raw)
            destination = target / source.name
            try:
                destination.write_text(
                    source.read_text(encoding="utf-8", errors="replace"), encoding="utf-8")
                copied.append(destination.name)
            except OSError as exc:
                messagebox.showerror("Savoirs", f"Copie impossible de {source.name} : {exc}")
        if copied:
            self._set_status(f"Ajoute : {', '.join(copied)}. Lance l'indexation.")
            self.ingest_knowledge(False)

    def delete_pack(self) -> None:
        selection = self.tree_packs.selection()
        if not selection:
            return
        name = self.tree_packs.item(selection[0], "values")[1]
        if not messagebox.askyesno("Savoirs", f"Supprimer le pack '{name}' de l'index ?\n"
                                              "Le fichier source n'est pas supprime."):
            return
        self.db.delete_pack(int(selection[0]))
        self.refresh_packs()

    def search_knowledge(self) -> None:
        if not self._require_project():
            return
        query = self.var_search.get().strip()
        if not query:
            return
        pack_ids = self.db.enabled_pack_ids(int(self.project["id"]))
        if not pack_ids:
            messagebox.showinfo("Savoirs", "Aucun pack actif sur ce projet.")
            return
        self._set_status("Recherche dans les savoirs...")

        def task() -> None:
            try:
                hits = self.engine.knowledge.search(query, pack_ids,
                                                    int(self.config_obj["rag_top_k"]))
                text = self.engine.knowledge.format_hits(hits, 12000) or "(aucun resultat)"
            except Exception as exc:  # pragma: no cover
                text = f"Erreur : {exc}"
            self.events.put(("status", "Recherche terminee."))
            self.events.put(("search", text))

        threading.Thread(target=task, daemon=True).start()

    def _show_search(self, text: str) -> None:
        self.txt_search.configure(state="normal")
        self.txt_search.delete("1.0", "end")
        self.txt_search.insert("1.0", text)
        self.txt_search.configure(state="disabled")

    # ======================================================= parametres
    def save_settings(self) -> None:
        numeric_int = {"num_ctx", "request_timeout", "context_budget_tokens",
                       "keep_last_messages", "summarize_after_messages", "rag_top_k",
                       "max_file_bytes", "max_manifest_files"}
        numeric_float = {"temperature_code", "temperature_light"}
        for key, var in self.setting_vars.items():
            value = var.get()
            if isinstance(var, tk.BooleanVar):
                self.config_obj[key] = bool(value)
            elif key in numeric_int:
                try:
                    self.config_obj[key] = int(float(str(value).strip()))
                except ValueError:
                    messagebox.showwarning("Parametres", f"Valeur entiere attendue pour {key}.")
                    return
            elif key in numeric_float:
                try:
                    self.config_obj[key] = float(str(value).replace(",", ".").strip())
                except ValueError:
                    messagebox.showwarning("Parametres", f"Valeur decimale attendue pour {key}.")
                    return
            else:
                self.config_obj[key] = str(value).strip()
        self.config_obj.save()
        self.engine.refresh_clients()
        self._update_model_label()
        self._set_status("Parametres enregistres.")

    def _check_ollama_async(self) -> None:
        def task() -> None:
            self.engine.refresh_clients()
            if self.engine.client.ping():
                try:
                    models = self.engine.client.list_models()
                except OllamaError:
                    models = []
                self.events.put(("models", models))
                self.events.put(("status", f"Ollama joignable ({len(models)} modele(s))."))
            else:
                self.events.put(("status", f"Ollama injoignable sur "
                                           f"{self.config_obj['ollama_url']}."))

        threading.Thread(target=task, daemon=True).start()

    def _load_models_async(self) -> None:
        self._check_ollama_async()

    def _apply_model_list(self, models: list[str]) -> None:
        for combo in getattr(self, "model_combos", []):
            combo.configure(values=models)

    # ============================================================= divers
    def _require_project(self) -> bool:
        if self.project is None:
            messagebox.showinfo("Projet", "Cree ou selectionne d'abord un projet.")
            return False
        return True

    @staticmethod
    def _open_path(path: Path) -> None:
        path = Path(path)
        try:
            if os.name == "nt":
                os.startfile(str(path))  # type: ignore[attr-defined]
            elif os.uname().sysname == "Darwin":  # pragma: no cover
                subprocess.Popen(["open", str(path)])
            else:
                subprocess.Popen(["xdg-open", str(path)])
        except Exception as exc:  # pragma: no cover
            messagebox.showinfo("Ouverture", f"Impossible d'ouvrir {path} : {exc}")

    def _on_close(self) -> None:
        if self.busy and not messagebox.askyesno(
                "Fermeture", "Une generation est en cours. Quitter quand meme ?"):
            return
        self.engine.stop()
        try:
            self.config_obj.save()
        except OSError:
            pass
        self.destroy()
